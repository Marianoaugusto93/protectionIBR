import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, decimal, boolean } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Configuração do alimentador radial
 */
export const feeders = mysqlTable("feeders", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  nominalVoltage: int("nominalVoltage").notNull(), // em kV
  sourceImpedanceR: decimal("sourceImpedanceR", { precision: 10, scale: 6 }).notNull(), // em Ohms
  sourceImpedanceX: decimal("sourceImpedanceX", { precision: 10, scale: 6 }).notNull(), // em Ohms
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Feeder = typeof feeders.$inferSelect;
export type InsertFeeder = typeof feeders.$inferInsert;

/**
 * Barras do alimentador
 */
export const buses = mysqlTable("buses", {
  id: int("id").autoincrement().primaryKey(),
  feederId: int("feederId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  position: int("position").notNull(), // posição sequencial no alimentador (0 = subestação)
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Bus = typeof buses.$inferSelect;
export type InsertBus = typeof buses.$inferInsert;

/**
 * Linhas (trechos) entre barras
 */
export const lines = mysqlTable("lines", {
  id: int("id").autoincrement().primaryKey(),
  feederId: int("feederId").notNull(),
  fromBusId: int("fromBusId").notNull(),
  toBusId: int("toBusId").notNull(),
  resistanceR: decimal("resistanceR", { precision: 10, scale: 6 }).notNull(), // em Ohms
  reactanceX: decimal("reactanceX", { precision: 10, scale: 6 }).notNull(), // em Ohms
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Line = typeof lines.$inferSelect;
export type InsertLine = typeof lines.$inferInsert;

/**
 * Equipamentos de proteção (chaves fusíveis e religadores)
 */
export const protectionDevices = mysqlTable("protectionDevices", {
  id: int("id").autoincrement().primaryKey(),
  feederId: int("feederId").notNull(),
  busId: int("busId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  type: mysqlEnum("type", ["fuse", "recloser"]).notNull(),
  pickupCurrent: decimal("pickupCurrent", { precision: 10, scale: 2 }).notNull(), // em Amperes
  timeDelay: decimal("timeDelay", { precision: 10, scale: 3 }).notNull(), // em segundos
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ProtectionDevice = typeof protectionDevices.$inferSelect;
export type InsertProtectionDevice = typeof protectionDevices.$inferInsert;

/**
 * Geração Distribuída (usinas)
 */
export const distributedGenerations = mysqlTable("distributedGenerations", {
  id: int("id").autoincrement().primaryKey(),
  feederId: int("feederId").notNull(),
  busId: int("busId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  capacity: int("capacity").notNull(), // em kW
  impedanceR: decimal("impedanceR", { precision: 10, scale: 6 }).notNull(), // em Ohms
  impedanceX: decimal("impedanceX", { precision: 10, scale: 6 }).notNull(), // em Ohms
  isActive: boolean("isActive").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type DistributedGeneration = typeof distributedGenerations.$inferSelect;
export type InsertDistributedGeneration = typeof distributedGenerations.$inferInsert;

/**
 * Resultados de simulação (cache para performance)
 */
export const simulationResults = mysqlTable("simulationResults", {
  id: int("id").autoincrement().primaryKey(),
  feederId: int("feederId").notNull(),
  gdId: int("gdId"), // null se sem GD
  gdActive: boolean("gdActive").notNull(),
  busId: int("busId").notNull(),
  shortCircuitCurrent: decimal("shortCircuitCurrent", { precision: 15, scale: 2 }).notNull(), // em Amperes
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type SimulationResult = typeof simulationResults.$inferSelect;
export type InsertSimulationResult = typeof simulationResults.$inferInsert;
