CREATE TABLE `buses` (
	`id` int AUTO_INCREMENT NOT NULL,
	`feederId` int NOT NULL,
	`name` varchar(255) NOT NULL,
	`position` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `buses_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `distributedGenerations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`feederId` int NOT NULL,
	`busId` int NOT NULL,
	`name` varchar(255) NOT NULL,
	`capacity` int NOT NULL,
	`impedanceR` decimal(10,6) NOT NULL,
	`impedanceX` decimal(10,6) NOT NULL,
	`isActive` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `distributedGenerations_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `feeders` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`description` text,
	`nominalVoltage` int NOT NULL,
	`sourceImpedanceR` decimal(10,6) NOT NULL,
	`sourceImpedanceX` decimal(10,6) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `feeders_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `lines` (
	`id` int AUTO_INCREMENT NOT NULL,
	`feederId` int NOT NULL,
	`fromBusId` int NOT NULL,
	`toBusId` int NOT NULL,
	`resistanceR` decimal(10,6) NOT NULL,
	`reactanceX` decimal(10,6) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `lines_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `protectionDevices` (
	`id` int AUTO_INCREMENT NOT NULL,
	`feederId` int NOT NULL,
	`busId` int NOT NULL,
	`name` varchar(255) NOT NULL,
	`type` enum('fuse','recloser') NOT NULL,
	`pickupCurrent` decimal(10,2) NOT NULL,
	`timeDelay` decimal(10,3) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `protectionDevices_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `simulationResults` (
	`id` int AUTO_INCREMENT NOT NULL,
	`feederId` int NOT NULL,
	`gdId` int,
	`gdActive` boolean NOT NULL,
	`busId` int NOT NULL,
	`shortCircuitCurrent` decimal(15,2) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `simulationResults_id` PRIMARY KEY(`id`)
);
