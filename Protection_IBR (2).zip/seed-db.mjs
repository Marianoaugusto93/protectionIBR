import { drizzle } from "drizzle-orm/mysql2";
import mysql from "mysql2/promise";
import {
  feeders,
  buses,
  lines,
  protectionDevices,
  distributedGenerations,
} from "./drizzle/schema.ts";

const DATABASE_URL = process.env.DATABASE_URL;

async function main() {
  if (!DATABASE_URL) {
    console.error("DATABASE_URL not set");
    process.exit(1);
  }

  const connection = await mysql.createConnection(DATABASE_URL);
  const db = drizzle(connection);

  console.log("🌱 Iniciando seed do banco de dados...");

  try {
    // Criar alimentador
    const feederResult = await db.insert(feeders).values({
      name: "Alimentador Principal",
      description: "Alimentador radial de distribuição com 4 barras",
      nominalVoltage: 13,
      sourceImpedanceR: 0.1,
      sourceImpedanceX: 0.05,
    });

    const feederId = feederResult[0].insertId;
    console.log(`✓ Alimentador criado (ID: ${feederId})`);

    // Criar barras
    const busesData = [
      { feederId, name: "Subestação", position: 0 },
      { feederId, name: "Barra 2", position: 1 },
      { feederId, name: "Barra 3", position: 2 },
      { feederId, name: "Barra 4", position: 3 },
    ];

    const busIds = [];
    for (const busData of busesData) {
      const result = await db.insert(buses).values(busData);
      busIds.push(result[0].insertId);
    }
    console.log(`✓ ${busIds.length} barras criadas`);

    // Criar linhas
    const linesData = [
      {
        feederId,
        fromBusId: busIds[0],
        toBusId: busIds[1],
        resistanceR: 0.5,
        reactanceX: 0.3,
      },
      {
        feederId,
        fromBusId: busIds[1],
        toBusId: busIds[2],
        resistanceR: 0.4,
        reactanceX: 0.25,
      },
      {
        feederId,
        fromBusId: busIds[2],
        toBusId: busIds[3],
        resistanceR: 0.35,
        reactanceX: 0.2,
      },
    ];

    for (const lineData of linesData) {
      await db.insert(lines).values(lineData);
    }
    console.log(`✓ ${linesData.length} linhas criadas`);

    // Criar equipamentos de proteção
    const devicesData = [
      {
        feederId,
        busId: busIds[1],
        name: "Chave Fusível 1",
        type: "fuse",
        pickupCurrent: 200,
        timeDelay: 0.1,
      },
      {
        feederId,
        busId: busIds[2],
        name: "Religador 1",
        type: "recloser",
        pickupCurrent: 150,
        timeDelay: 0.5,
      },
      {
        feederId,
        busId: busIds[3],
        name: "Chave Fusível 2",
        type: "fuse",
        pickupCurrent: 100,
        timeDelay: 0.1,
      },
    ];

    for (const deviceData of devicesData) {
      await db.insert(protectionDevices).values(deviceData);
    }
    console.log(`✓ ${devicesData.length} equipamentos de proteção criados`);

    // Criar Geração Distribuída
    const gdResult = await db.insert(distributedGenerations).values({
      feederId,
      busId: busIds[2],
      name: "Usina Solar 500kW",
      capacity: 500,
      impedanceR: 0.05,
      impedanceX: 0.02,
      isActive: false,
    });

    console.log(`✓ Geração Distribuída criada`);

    console.log("\n✅ Seed concluído com sucesso!");
    console.log(`\nDados criados:`);
    console.log(`- Alimentador: ${feederId}`);
    console.log(`- Barras: ${busIds.join(", ")}`);
    console.log(`- Linhas: ${linesData.length}`);
    console.log(`- Equipamentos de proteção: ${devicesData.length}`);
    console.log(`- Geração Distribuída: 1`);

    await connection.end();
  } catch (error) {
    console.error("❌ Erro durante seed:", error);
    process.exit(1);
  }
}

main();
