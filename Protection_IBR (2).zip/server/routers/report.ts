import { z } from "zod";
import { publicProcedure, router } from "../_core/trpc";
import { generateProtectionReportPDF } from "../pdf-report";

export const reportRouter = router({
  exportProtectionAnalysis: publicProcedure
    .input(
      z.object({
        feederName: z.string(),
        gdActive: z.boolean(),
        gdName: z.string().optional(),
        gdCapacity: z.number().optional(),
        sourceImpedanceR: z.number(),
        resultsWithoutGD: z.array(
          z.object({
            busId: z.number(),
            busName: z.string(),
            shortCircuitCurrent: z.number(),
            impedanceR: z.number(),
            impedanceX: z.number(),
            impedanceTotal: z.number(),
            protectionDevices: z
              .array(
                z.object({
                  id: z.number(),
                  name: z.string(),
                  type: z.enum(["fuse", "recloser"]),
                  pickupCurrent: z.number(),
                  canDetect: z.boolean().optional(),
                  operationTime: z.number().nullable().optional(),
                })
              )
              .optional(),
          })
        ),
        resultsWithGD: z.array(
          z.object({
            busId: z.number(),
            busName: z.string(),
            shortCircuitCurrent: z.number(),
            impedanceR: z.number(),
            impedanceX: z.number(),
            impedanceTotal: z.number(),
            protectionDevices: z
              .array(
                z.object({
                  id: z.number(),
                  name: z.string(),
                  type: z.enum(["fuse", "recloser"]),
                  pickupCurrent: z.number(),
                  canDetect: z.boolean().optional(),
                  operationTime: z.number().nullable().optional(),
                })
              )
              .optional(),
          })
        ),
        failures: z.array(
          z.object({
            type: z.enum(["no_detection", "slow_operation"]),
            busName: z.string(),
            deviceName: z.string(),
            deviceType: z.enum(["fuse", "recloser"]),
            icc: z.number().optional(),
            pickup: z.number().optional(),
            operationTime: z.number().optional(),
            severity: z.enum(["high", "medium"]),
          })
        ),
        blindingRisk: z.boolean(),
        coordinationIssues: z.boolean(),
      })
    )
    .mutation(async ({ input }) => {
      try {
        const pdfBuffer = await generateProtectionReportPDF({
          title: "Relatório de Análise de Proteção",
          timestamp: new Date(),
          feederName: input.feederName,
          gdActive: input.gdActive,
          gdName: input.gdName,
          gdCapacity: input.gdCapacity,
          sourceImpedanceR: input.sourceImpedanceR,
          resultsWithoutGD: input.resultsWithoutGD,
          resultsWithGD: input.resultsWithGD,
          failures: input.failures,
          blindingRisk: input.blindingRisk,
          coordinationIssues: input.coordinationIssues,
        });

        return {
          success: true,
          pdfBase64: pdfBuffer.toString("base64"),
          filename: `relatorio-protecao-${new Date().toISOString().split("T")[0]}.pdf`,
        };
      } catch (error) {
        console.error("Erro ao gerar PDF:", error);
        throw new Error("Erro ao gerar relatório em PDF");
      }
    }),
});
