import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { reportRouter } from "./routers/report";
import { z } from "zod";
import {
  getFeederById,
  getAllFeeders,
  createFeeder,
  getBusesByFeederId,
  createBus,
  getLinesByFeederId,
  createLine,
  getProtectionDevicesByFeederId,
  createProtectionDevice,
  getDistributedGenerationsByFeederId,
  getDistributedGenerationById,
  createDistributedGeneration,
  updateDistributedGenerationStatus,
  getSimulationResults,
  saveSimulationResult,
} from "./db";
import {
  calculateAllShortCircuits,
  canDetectFault,
  calculateOperationTime,
} from "./calculations";

export const appRouter = router({
  system: systemRouter,
  report: reportRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // ============ Feeder Management ============
  feeder: router({
    list: publicProcedure.query(async () => {
      return await getAllFeeders();
    }),

    getById: publicProcedure
      .input(z.object({ feederId: z.number() }))
      .query(async ({ input }) => {
        return await getFeederById(input.feederId);
      }),

    create: protectedProcedure
      .input(
        z.object({
          name: z.string(),
          description: z.string().optional(),
          nominalVoltage: z.number(),
          sourceImpedanceR: z.number(),
          sourceImpedanceX: z.number(),
        })
      )
      .mutation(async ({ input }) => {
        return await createFeeder(input);
      }),
  }),

  // ============ Bus Management ============
  bus: router({
    listByFeeder: publicProcedure
      .input(z.object({ feederId: z.number() }))
      .query(async ({ input }) => {
        return await getBusesByFeederId(input.feederId);
      }),

    create: protectedProcedure
      .input(
        z.object({
          feederId: z.number(),
          name: z.string(),
          position: z.number(),
        })
      )
      .mutation(async ({ input }) => {
        return await createBus(input);
      }),
  }),

  // ============ Line Management ============
  line: router({
    listByFeeder: publicProcedure
      .input(z.object({ feederId: z.number() }))
      .query(async ({ input }) => {
        return await getLinesByFeederId(input.feederId);
      }),

    create: protectedProcedure
      .input(
        z.object({
          feederId: z.number(),
          fromBusId: z.number(),
          toBusId: z.number(),
          resistanceR: z.number(),
          reactanceX: z.number(),
        })
      )
      .mutation(async ({ input }) => {
        return await createLine(input);
      }),
  }),

  // ============ Protection Device Management ============
  protectionDevice: router({
    listByFeeder: publicProcedure
      .input(z.object({ feederId: z.number() }))
      .query(async ({ input }) => {
        return await getProtectionDevicesByFeederId(input.feederId);
      }),

    create: protectedProcedure
      .input(
        z.object({
          feederId: z.number(),
          busId: z.number(),
          name: z.string(),
          type: z.enum(["fuse", "recloser"]),
          pickupCurrent: z.number(),
          timeDelay: z.number(),
        })
      )
      .mutation(async ({ input }) => {
        return await createProtectionDevice(input);
      }),
  }),

  // ============ Distributed Generation Management ============
  distributedGeneration: router({
    listByFeeder: publicProcedure
      .input(z.object({ feederId: z.number() }))
      .query(async ({ input }) => {
        return await getDistributedGenerationsByFeederId(input.feederId);
      }),

    getById: publicProcedure
      .input(z.object({ gdId: z.number() }))
      .query(async ({ input }) => {
        return await getDistributedGenerationById(input.gdId);
      }),

    create: protectedProcedure
      .input(
        z.object({
          feederId: z.number(),
          busId: z.number(),
          name: z.string(),
          capacity: z.number(),
          impedanceR: z.number(),
          impedanceX: z.number(),
        })
      )
      .mutation(async ({ input }) => {
        return await createDistributedGeneration(input);
      }),

    toggleStatus: protectedProcedure
      .input(z.object({ gdId: z.number(), isActive: z.boolean() }))
      .mutation(async ({ input }) => {
        return await updateDistributedGenerationStatus(input.gdId, input.isActive);
      }),
  }),

  // ============ Simulation ============
  simulation: router({
    calculateShortCircuits: publicProcedure
      .input(
        z.object({
          feederId: z.number(),
          gdId: z.number().optional(),
          gdActive: z.boolean(),
        })
      )
      .query(async ({ input }) => {
        const feeder = await getFeederById(input.feederId);
        if (!feeder) {
          throw new Error("Feeder not found");
        }

        const buses = await getBusesByFeederId(input.feederId);
        const lines = await getLinesByFeederId(input.feederId);
        const protectionDevices = await getProtectionDevicesByFeederId(input.feederId);

        let gdData = undefined;
        if (input.gdActive && input.gdId) {
          const gd = await getDistributedGenerationById(input.gdId);
          if (gd) {
            gdData = {
              busId: gd.busId,
              impedanceR: parseFloat(gd.impedanceR.toString()),
              impedanceX: parseFloat(gd.impedanceX.toString()),
              isActive: true,
            };
          }
        }

        // Converter Decimal para number
        const source = {
          impedanceR: parseFloat(feeder.sourceImpedanceR.toString()),
          impedanceX: parseFloat(feeder.sourceImpedanceX.toString()),
          nominalVoltage: feeder.nominalVoltage,
        };

        const busesData = buses.map(b => ({
          id: b.id,
          name: b.name,
          position: b.position,
        }));

        const linesData = lines.map(l => ({
          fromBusId: l.fromBusId,
          toBusId: l.toBusId,
          resistanceR: parseFloat(l.resistanceR.toString()),
          reactanceX: parseFloat(l.reactanceX.toString()),
        }));

        // Calcular curto-circuitos
        const shortCircuits = calculateAllShortCircuits(busesData, linesData, source, gdData);

        // Enriquecer com informações de proteção
        const results = shortCircuits.map(sc => {
          const devicesAtBus = protectionDevices.filter(d => d.busId === sc.busId);
          const protectionInfo = devicesAtBus.map(device => ({
            id: device.id,
            name: device.name,
            type: device.type,
            pickupCurrent: parseFloat(device.pickupCurrent.toString()),
            timeDelay: parseFloat(device.timeDelay.toString()),
            canDetect: canDetectFault(sc.shortCircuitCurrent, parseFloat(device.pickupCurrent.toString())),
            operationTime: calculateOperationTime(
              sc.shortCircuitCurrent,
              parseFloat(device.pickupCurrent.toString()),
              parseFloat(device.timeDelay.toString())
            ),
          }));

          return {
            ...sc,
            protectionDevices: protectionInfo,
          };
        });

        // Salvar resultados em cache
        for (const result of results) {
          await saveSimulationResult({
            feederId: input.feederId,
            gdId: input.gdId || null,
            gdActive: input.gdActive,
            busId: result.busId,
            shortCircuitCurrent: result.shortCircuitCurrent,
          });
        }

        return results;
      }),

    getResults: publicProcedure
      .input(
        z.object({
          feederId: z.number(),
          gdActive: z.boolean(),
          gdId: z.number().optional(),
        })
      )
      .query(async ({ input }) => {
        return await getSimulationResults(input.feederId, input.gdActive, input.gdId);
      }),
  }),
});

export type AppRouter = typeof appRouter;
