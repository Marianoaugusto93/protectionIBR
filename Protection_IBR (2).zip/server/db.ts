import { eq, and } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, feeders, buses, lines, protectionDevices, distributedGenerations, simulationResults } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// ============ Feeder Queries ============

export async function getFeederById(feederId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(feeders).where(eq(feeders.id, feederId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getAllFeeders() {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(feeders);
}

export async function createFeeder(data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(feeders).values(data);
  return result;
}

// ============ Bus Queries ============

export async function getBusesByFeederId(feederId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(buses).where(eq(buses.feederId, feederId));
}

export async function getBusById(busId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(buses).where(eq(buses.id, busId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createBus(data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(buses).values(data);
  return result;
}

// ============ Line Queries ============

export async function getLinesByFeederId(feederId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(lines).where(eq(lines.feederId, feederId));
}

export async function createLine(data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(lines).values(data);
  return result;
}

// ============ Protection Device Queries ============

export async function getProtectionDevicesByFeederId(feederId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(protectionDevices).where(eq(protectionDevices.feederId, feederId));
}

export async function createProtectionDevice(data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(protectionDevices).values(data);
  return result;
}

// ============ Distributed Generation Queries ============

export async function getDistributedGenerationsByFeederId(feederId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(distributedGenerations).where(eq(distributedGenerations.feederId, feederId));
}

export async function getDistributedGenerationById(gdId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(distributedGenerations).where(eq(distributedGenerations.id, gdId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createDistributedGeneration(data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(distributedGenerations).values(data);
  return result;
}

export async function updateDistributedGenerationStatus(gdId: number, isActive: boolean) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.update(distributedGenerations)
    .set({ isActive, updatedAt: new Date() })
    .where(eq(distributedGenerations.id, gdId));
}

// ============ Simulation Result Queries ============

export async function getSimulationResults(feederId: number, gdActive: boolean, gdId?: number) {
  const db = await getDb();
  if (!db) return [];
  
  const conditions = [
    eq(simulationResults.feederId, feederId),
    eq(simulationResults.gdActive, gdActive),
  ];
  
  if (gdId !== undefined) {
    conditions.push(eq(simulationResults.gdId, gdId));
  }
  
  return await db.select().from(simulationResults).where(and(...conditions));
}

export async function saveSimulationResult(data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  // Delete existing results for this configuration
  await db.delete(simulationResults).where(
    and(
      eq(simulationResults.feederId, data.feederId),
      eq(simulationResults.gdActive, data.gdActive),
      data.gdId ? eq(simulationResults.gdId, data.gdId) : undefined
    )
  );
  
  // Insert new results
  return await db.insert(simulationResults).values(data);
}
