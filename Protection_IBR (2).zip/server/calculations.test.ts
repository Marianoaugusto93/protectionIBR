import { describe, expect, it } from "vitest";
import {
  calculateThéveninImpedance,
  calculateShortCircuitCurrent,
  calculateAllShortCircuits,
  canDetectFault,
  calculateOperationTime,
} from "./calculations";

describe("Short Circuit Calculations", () => {
  const buses = [
    { id: 1, name: "Subestação", position: 0 },
    { id: 2, name: "Barra 2", position: 1 },
    { id: 3, name: "Barra 3", position: 2 },
  ];

  const lines = [
    { fromBusId: 1, toBusId: 2, resistanceR: 0.5, reactanceX: 0.3 },
    { fromBusId: 2, toBusId: 3, resistanceR: 0.4, reactanceX: 0.25 },
  ];

  const source = {
    impedanceR: 0.1,
    impedanceX: 0.05,
    nominalVoltage: 13.8, // kV
  };

  describe("calculateThéveninImpedance", () => {
    it("should calculate impedance at source bus", () => {
      const impedance = calculateThéveninImpedance(1, buses, lines, source);
      expect(impedance.R).toBeCloseTo(0.1, 1);
      expect(impedance.X).toBeCloseTo(0.05, 1);
    });

    it("should calculate impedance at bus 2", () => {
      const impedance = calculateThéveninImpedance(2, buses, lines, source);
      // Impedância deve ser maior ou igual à da fonte
      expect(impedance.R).toBeGreaterThanOrEqual(source.impedanceR);
      expect(impedance.X).toBeGreaterThanOrEqual(source.impedanceX);
    });

    it("should calculate impedance at bus 3", () => {
      const impedance = calculateThéveninImpedance(3, buses, lines, source);
      // Impedância em bus 3 deve ser maior que em bus 2
      const impedanceBus2 = calculateThéveninImpedance(2, buses, lines, source);
      expect(impedance.R).toBeGreaterThan(impedanceBus2.R);
      expect(impedance.X).toBeGreaterThan(impedanceBus2.X);
    });
  });

  describe("calculateShortCircuitCurrent", () => {
    it("should calculate short circuit current correctly", () => {
      const impedanceR = 0.1;
      const impedanceX = 0.05;
      const nominalVoltage = 13.8;

      const icc = calculateShortCircuitCurrent(impedanceR, impedanceX, nominalVoltage);

      // Z = sqrt(0.1^2 + 0.05^2) = sqrt(0.0125) ≈ 0.1118
      // Icc = (13800 / 0.1118) ≈ 123,400 A
      expect(icc).toBeGreaterThan(100000);
      expect(icc).toBeLessThan(150000);
    });

    it("should return 0 for zero impedance", () => {
      const icc = calculateShortCircuitCurrent(0, 0, 13.8);
      expect(icc).toBe(0);
    });
  });

  describe("calculateAllShortCircuits", () => {
    it("should calculate short circuits for all buses", () => {
      const results = calculateAllShortCircuits(buses, lines, source);

      expect(results).toHaveLength(3);
      expect(results[0].busId).toBe(1);
      expect(results[1].busId).toBe(2);
      expect(results[2].busId).toBe(3);

      // Curto-circuito deve diminuir conforme se afasta da subestação
      expect(results[0].shortCircuitCurrent).toBeGreaterThanOrEqual(results[1].shortCircuitCurrent);
      expect(results[1].shortCircuitCurrent).toBeGreaterThanOrEqual(results[2].shortCircuitCurrent);
    });

    it("should include GD in calculations when active", () => {
      const gdData = {
        busId: 2,
        impedanceR: 0.05,
        impedanceX: 0.02,
        isActive: true,
      };

      const resultsWithoutGD = calculateAllShortCircuits(buses, lines, source);
      const resultsWithGD = calculateAllShortCircuits(buses, lines, source, gdData);

      // Com GD ativa, o curto-circuito na barra 2 deve aumentar ou permanecer similar
      expect(resultsWithGD[1].shortCircuitCurrent).toBeGreaterThanOrEqual(
        resultsWithoutGD[1].shortCircuitCurrent * 0.95 // Permite pequena variação
      );
    });
  });

  describe("canDetectFault", () => {
    it("should detect fault when current exceeds pickup", () => {
      const canDetect = canDetectFault(5000, 3000);
      expect(canDetect).toBe(true);
    });

    it("should not detect fault when current below pickup", () => {
      const canDetect = canDetectFault(2000, 3000);
      expect(canDetect).toBe(false);
    });

    it("should detect fault at pickup threshold", () => {
      const canDetect = canDetectFault(3000, 3000);
      expect(canDetect).toBe(true);
    });
  });

  describe("calculateOperationTime", () => {
    it("should return null when fault not detected", () => {
      const time = calculateOperationTime(2000, 3000, 0.5);
      expect(time).toBeNull();
    });

    it("should calculate operation time when fault detected", () => {
      const time = calculateOperationTime(6000, 3000, 0.5);
      expect(time).not.toBeNull();
      expect(time).toBeGreaterThan(0);
    });

    it("should respect minimum time delay", () => {
      const time = calculateOperationTime(3000.1, 3000, 0.5);
      expect(time).toBeGreaterThanOrEqual(0.05); // 10% of 0.5
    });
  });
});
