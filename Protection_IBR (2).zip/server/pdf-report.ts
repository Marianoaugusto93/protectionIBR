import { jsPDF } from "jspdf";
import "jspdf-autotable";

interface ProtectionDevice {
  id: number;
  name: string;
  type: "fuse" | "recloser";
  pickupCurrent: number;
  canDetect?: boolean;
  operationTime?: number | null;
}

interface ShortCircuitResult {
  busId: number;
  busName: string;
  shortCircuitCurrent: number;
  impedanceR: number;
  impedanceX: number;
  impedanceTotal: number;
  protectionDevices?: ProtectionDevice[];
}

interface ProtectionFailure {
  type: "no_detection" | "slow_operation";
  busName: string;
  deviceName: string;
  deviceType: "fuse" | "recloser";
  icc?: number;
  pickup?: number;
  operationTime?: number;
  severity: "high" | "medium";
}

interface ReportData {
  title: string;
  timestamp: Date;
  feederName: string;
  gdActive: boolean;
  gdName?: string;
  gdCapacity?: number;
  sourceImpedanceR: number;
  resultsWithoutGD: ShortCircuitResult[];
  resultsWithGD: ShortCircuitResult[];
  failures: ProtectionFailure[];
  blindingRisk: boolean;
  coordinationIssues: boolean;
}

export async function generateProtectionReportPDF(data: ReportData): Promise<Buffer> {
  const doc = new jsPDF({
    orientation: "portrait",
    unit: "mm",
    format: "a4",
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const margin = 15;
  const contentWidth = pageWidth - 2 * margin;
  let yPosition = margin;

  // Helper functions
  const addTitle = (text: string, size: number = 16) => {
    doc.setFontSize(size);
    doc.setFont("helvetica", "bold");
    doc.text(text, margin, yPosition);
    yPosition += size / 2 + 5;
  };

  const addSubtitle = (text: string, size: number = 12) => {
    doc.setFontSize(size);
    doc.setFont("helvetica", "bold");
    doc.text(text, margin, yPosition);
    yPosition += size / 2 + 3;
  };

  const addText = (text: string, size: number = 10, bold: boolean = false) => {
    doc.setFontSize(size);
    doc.setFont("helvetica", bold ? "bold" : "normal");
    const lines = doc.splitTextToSize(text, contentWidth);
    doc.text(lines, margin, yPosition);
    yPosition += lines.length * (size / 3) + 2;
  };

  const addSpace = (height: number = 5) => {
    yPosition += height;
  };

  const checkPageBreak = (height: number = 30) => {
    if (yPosition + height > pageHeight - margin) {
      doc.addPage();
      yPosition = margin;
    }
  };

  // Header
  doc.setFillColor(15, 23, 42); // slate-900
  doc.rect(0, 0, pageWidth, 30, "F");

  doc.setTextColor(255, 255, 255);
  doc.setFontSize(20);
  doc.setFont("helvetica", "bold");
  doc.text("RELATÓRIO DE ANÁLISE DE PROTEÇÃO", margin, 15);

  doc.setTextColor(0, 0, 0);
  yPosition = 35;

  // Executive Summary
  addTitle("Resumo Executivo");

  const statusColor = data.failures.length === 0 ? "#10b981" : "#ef4444";
  const statusText =
    data.failures.length === 0
      ? "✓ Proteção Operando Corretamente"
      : `✗ ${data.failures.length} Problema(s) de Proteção Detectado(s)`;

  doc.setTextColor(data.failures.length === 0 ? 16 : 239, data.failures.length === 0 ? 185 : 68, data.failures.length === 0 ? 129 : 68);
  addText(statusText, 11, true);
  doc.setTextColor(0, 0, 0);

  addText(
    `Alimentador: ${data.feederName}\nData: ${data.timestamp.toLocaleString("pt-BR")}\nGeração Distribuída: ${data.gdActive ? "ATIVA" : "INATIVA"}${data.gdName ? ` (${data.gdName})` : ""}`
  );

  addSpace(5);

  // System Parameters
  checkPageBreak(40);
  addSubtitle("Parâmetros do Sistema");

  const paramData = [
    ["Parâmetro", "Valor"],
    ["Impedância da Fonte (R)", `${data.sourceImpedanceR.toFixed(4)} Ω`],
    ["Status da GD", data.gdActive ? "ATIVA" : "INATIVA"],
  ];

  if (data.gdActive && data.gdCapacity) {
    paramData.push(["Capacidade da GD", `${data.gdCapacity} kW`]);
  }

  (doc as any).autoTable({
    head: [paramData[0]],
    body: paramData.slice(1),
    startY: yPosition,
    margin: margin,
    theme: "grid",
    headStyles: { fillColor: [51, 65, 85], textColor: 255 },
    bodyStyles: { textColor: 0 },
    columnStyles: { 0: { cellWidth: contentWidth * 0.4 }, 1: { cellWidth: contentWidth * 0.6 } },
  });

  yPosition = (doc as any).lastAutoTable.finalY + 10;

  // Short Circuit Results - Without GD
  checkPageBreak(50);
  addSubtitle("Resultados de Curto-Circuito - SEM Geração Distribuída");

  const withoutGDData: string[][] = [
    ["Barra", "ICC (kA)", "Z (Ω)", "R (Ω)", "X (Ω)"],
    ...data.resultsWithoutGD.map((r) => [
      r.busName,
      (r.shortCircuitCurrent / 1000).toFixed(2),
      r.impedanceTotal.toFixed(4),
      r.impedanceR.toFixed(4),
      r.impedanceX.toFixed(4),
    ]),
  ];

  (doc as any).autoTable({
    head: [withoutGDData[0]],
    body: withoutGDData.slice(1),
    startY: yPosition,
    margin: margin,
    theme: "grid",
    headStyles: { fillColor: [59, 130, 246], textColor: 255 },
    bodyStyles: { textColor: 0 },
    columnStyles: {
      0: { cellWidth: contentWidth * 0.25 },
      1: { cellWidth: contentWidth * 0.15 },
      2: { cellWidth: contentWidth * 0.2 },
      3: { cellWidth: contentWidth * 0.2 },
      4: { cellWidth: contentWidth * 0.2 },
    },
  });

  yPosition = (doc as any).lastAutoTable.finalY + 10;

  // Short Circuit Results - With GD
  if (data.gdActive) {
    checkPageBreak(50);
    addSubtitle("Resultados de Curto-Circuito - COM Geração Distribuída");

    const withGDData: string[][] = [
      ["Barra", "ICC (kA)", "Z (Ω)", "R (Ω)", "X (Ω)", "Variação (%)"],
      ...data.resultsWithGD.map((r) => {
        const resultWithout = data.resultsWithoutGD.find((rw) => rw.busId === r.busId);
        const variation =
          resultWithout && resultWithout.shortCircuitCurrent > 0
            ? (((r.shortCircuitCurrent - resultWithout.shortCircuitCurrent) /
                resultWithout.shortCircuitCurrent) *
                100).toFixed(1)
            : "0.0";

        return [
          r.busName,
          (r.shortCircuitCurrent / 1000).toFixed(2),
          r.impedanceTotal.toFixed(4),
          r.impedanceR.toFixed(4),
          r.impedanceX.toFixed(4),
          `${variation}%`,
        ];
      }),
    ];

    (doc as any).autoTable({
      head: [withGDData[0]],
      body: withGDData.slice(1),
      startY: yPosition,
      margin: margin,
      theme: "grid",
      headStyles: { fillColor: [168, 85, 247], textColor: 255 },
      bodyStyles: { textColor: 0 },
      columnStyles: {
        0: { cellWidth: contentWidth * 0.2 },
        1: { cellWidth: contentWidth * 0.15 },
        2: { cellWidth: contentWidth * 0.15 },
        3: { cellWidth: contentWidth * 0.15 },
        4: { cellWidth: contentWidth * 0.15 },
        5: { cellWidth: contentWidth * 0.2 },
      },
    });

    yPosition = (doc as any).lastAutoTable.finalY + 10;
  }

  // Protection Analysis
  checkPageBreak(40);
  addSubtitle("Análise de Proteção");

  if (data.failures.length === 0) {
    addText("✓ Todos os equipamentos conseguem detectar faltas e estão coordenados corretamente.");
  } else {
    addText(`Foram detectados ${data.failures.length} problema(s) de proteção:`);
    addSpace(3);

    data.failures.forEach((failure, idx) => {
      doc.setFont("helvetica", "bold");
      doc.setFontSize(10);
      doc.text(`${idx + 1}. ${failure.deviceName} (${failure.busName})`, margin + 3, yPosition);
      yPosition += 5;

      doc.setFont("helvetica", "normal");
      doc.setFontSize(9);

      if (failure.type === "no_detection") {
        const lines = doc.splitTextToSize(
          `Tipo: Falha de Detecção\nICC na barra: ${(failure.icc! / 1000).toFixed(2)} kA\nPickup do equipamento: ${failure.pickup?.toFixed(0)} A\nO equipamento NÃO consegue detectar a falta.`,
          contentWidth - 6
        );
        doc.text(lines, margin + 6, yPosition);
        yPosition += lines.length * 3.5 + 2;
      } else {
        const lines = doc.splitTextToSize(
          `Tipo: Atuação Lenta\nTempo de operação: ${failure.operationTime?.toFixed(3)} s\nA atuação lenta pode permitir danos ao equipamento.`,
          contentWidth - 6
        );
        doc.text(lines, margin + 6, yPosition);
        yPosition += lines.length * 3.5 + 2;
      }

      addSpace(2);
      checkPageBreak(30);
    });
  }

  // Risk Assessment
  checkPageBreak(40);
  addSubtitle("Avaliação de Riscos");

  const risks = [
    {
      name: "Blinding (Proteção Cega)",
      risk: data.blindingRisk ? "ALTO" : "BAIXO",
      description: data.blindingRisk
        ? "Fonte fraca + GD pode reduzir ICC em algumas barras"
        : "Risco baixo de proteção cega",
    },
    {
      name: "Coordenação de Proteção",
      risk: data.coordinationIssues ? "MÉDIO" : "BAIXO",
      description: data.coordinationIssues
        ? "Múltiplos equipamentos podem atuar simultaneamente"
        : "Equipamentos coordenados corretamente",
    },
    {
      name: "Detecção de Faltas",
      risk: data.failures.length > 0 ? "ALTO" : "BAIXO",
      description:
        data.failures.length > 0
          ? `${data.failures.length} equipamento(s) não conseguem detectar`
          : "Todos os equipamentos conseguem detectar",
    },
  ];

  const riskData = [
    ["Risco", "Nível", "Descrição"],
    ...risks.map((r) => [r.name, r.risk, r.description]),
  ];

  (doc as any).autoTable({
    head: [riskData[0]],
    body: riskData.slice(1),
    startY: yPosition,
    margin: margin,
    theme: "grid",
    headStyles: { fillColor: [220, 38, 38], textColor: 255 },
    bodyStyles: { textColor: 0 },
    columnStyles: {
      0: { cellWidth: contentWidth * 0.3 },
      1: { cellWidth: contentWidth * 0.15 },
      2: { cellWidth: contentWidth * 0.55 },
    },
  });

  yPosition = (doc as any).lastAutoTable.finalY + 10;

  // Recommendations
  checkPageBreak(40);
  addSubtitle("Recomendações Técnicas");

  if (data.failures.length === 0 && !data.blindingRisk && !data.coordinationIssues) {
    addText("O sistema de proteção está operando adequadamente. Recomenda-se:");
    addText("• Manter monitoramento periódico dos equipamentos de proteção");
    addText("• Realizar testes de operação dos equipamentos conforme normas");
    addText("• Documentar os parâmetros de proteção atuais");
  } else {
    if (data.failures.length > 0) {
      addText("Para resolver os problemas de proteção detectados:");
      addText("• Reduzir pickup current dos equipamentos com falha de detecção");
      addText("• Aumentar a força da fonte (reduzir impedância) se possível");
      addText("• Reposicionar equipamentos de proteção mais próximos às faltas");
      addText("• Adicionar equipamentos de proteção complementares");
      addSpace(3);
    }

    if (data.blindingRisk) {
      addText("Para mitigar risco de blinding:");
      addText("• Revisar impedância da fonte (aumentar força da subestação)");
      addText("• Considerar reduzir capacidade da GD ou reposicioná-la");
      addText("• Implementar proteção de frequência ou tensão na GD");
      addSpace(3);
    }

    if (data.coordinationIssues) {
      addText("Para melhorar coordenação de proteção:");
      addText("• Ajustar time delays para garantir seletividade");
      addText("• Equipamentos a montante devem ter pickup maior");
      addText("• Realizar análise de coordenação com software especializado");
    }
  }

  // Footer
  doc.setFontSize(8);
  doc.setTextColor(100, 100, 100);
  doc.text(
    `Gerado em: ${new Date().toLocaleString("pt-BR")} | Protection IBR - Simulador de Geração Distribuída`,
    margin,
    pageHeight - 10
  );

  return Buffer.from(doc.output("arraybuffer"));
}
