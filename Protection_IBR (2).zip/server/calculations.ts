/**
 * Módulo de cálculos de curto-circuito para alimentadores radiais
 * Utiliza o método de impedâncias para calcular níveis de falta
 */

interface BusData {
  id: number;
  name: string;
  position: number;
}

interface LineData {
  fromBusId: number;
  toBusId: number;
  resistanceR: number;
  reactanceX: number;
}

interface SourceData {
  impedanceR: number;
  impedanceX: number;
  nominalVoltage: number; // em kV
}

interface GDData {
  busId: number;
  impedanceR: number;
  impedanceX: number;
  isActive: boolean;
}

interface ShortCircuitResult {
  busId: number;
  busName: string;
  impedanceR: number;
  impedanceX: number;
  impedanceZ: number;
  shortCircuitCurrent: number; // em Amperes
}

/**
 * Calcula a impedância de Thévenin vista de uma barra específica
 * Considera a impedância da fonte e das linhas até essa barra
 */
export function calculateThéveninImpedance(
  targetBusId: number,
  buses: BusData[],
  lines: LineData[],
  source: SourceData,
  gdData?: GDData
): { R: number; X: number } {
  // Encontra o caminho da barra alvo até a subestação
  const path = findPathToSource(targetBusId, buses, lines);
  
  let totalR = source.impedanceR;
  let totalX = source.impedanceX;
  
  // Reconstrói o caminho da subestação até a barra alvo
  const fullPath = [0, ...path.reverse()];
  
  // Soma as impedâncias das linhas no caminho
  for (let i = 0; i < fullPath.length - 1; i++) {
    const fromBusId = fullPath[i];
    const toBusId = fullPath[i + 1];
    
    const line = lines.find(l => 
      (l.fromBusId === fromBusId && l.toBusId === toBusId) ||
      (l.toBusId === fromBusId && l.fromBusId === toBusId)
    );
    
    if (line) {
      totalR += line.resistanceR;
      totalX += line.reactanceX;
    }
  }
  
  // Se GD está ativa, reduz a impedância (GD contribui para curto)
  if (gdData && gdData.isActive && gdData.busId === targetBusId) {
    // Impedância em paralelo: GD e fonte
    const gdZ = Math.sqrt(gdData.impedanceR ** 2 + gdData.impedanceX ** 2);
    const sourceZ = Math.sqrt(totalR ** 2 + totalX ** 2);
    
    // Aproximação: reduz a impedância total
    const reductionFactor = gdZ / (gdZ + sourceZ);
    totalR = totalR * (1 - reductionFactor * 0.5);
    totalX = totalX * (1 - reductionFactor * 0.5);
  }
  
  return { R: totalR, X: totalX };
}

/**
 * Encontra o caminho (lista de barras) da barra alvo até a subestação
 */
function findPathToSource(targetBusId: number, buses: BusData[], lines: LineData[]): number[] {
  const path: number[] = [];
  let currentBusId = targetBusId;
  
  // Caminha de trás para frente até a subestação (posição 0)
  while (currentBusId !== 0) {
    const currentBus = buses.find(b => b.id === currentBusId);
    if (!currentBus) break;
    
    // Encontra a linha que conecta a barra atual à anterior (em direção à subestação)
    let nextBusId: number | undefined;
    
    for (const line of lines) {
      if (line.fromBusId === currentBusId) {
        const nextBus = buses.find(b => b.id === line.toBusId);
        if (nextBus && nextBus.position < currentBus.position) {
          nextBusId = line.toBusId;
          break;
        }
      } else if (line.toBusId === currentBusId) {
        const nextBus = buses.find(b => b.id === line.fromBusId);
        if (nextBus && nextBus.position < currentBus.position) {
          nextBusId = line.fromBusId;
          break;
        }
      }
    }
    
    if (nextBusId === undefined) break;
    
    path.push(nextBusId);
    currentBusId = nextBusId;
  }
  
  return path;
}

/**
 * Calcula o nível de curto-circuito em uma barra
 * Fórmula: Icc = (V_nominal * 1000) / Z_thévenin
 */
export function calculateShortCircuitCurrent(
  impedanceR: number,
  impedanceX: number,
  nominalVoltage: number
): number {
  const impedanceZ = Math.sqrt(impedanceR ** 2 + impedanceX ** 2);
  
  if (impedanceZ === 0) {
    return 0;
  }
  
  // V em Volts, Z em Ohms, I em Amperes
  const voltageVolts = nominalVoltage * 1000;
  const shortCircuitCurrent = voltageVolts / impedanceZ;
  
  return shortCircuitCurrent;
}

/**
 * Calcula os níveis de curto-circuito para todas as barras
 */
export function calculateAllShortCircuits(
  buses: BusData[],
  lines: LineData[],
  source: SourceData,
  gdData?: GDData
): ShortCircuitResult[] {
  return buses.map(bus => {
    const { R, X } = calculateThéveninImpedance(bus.id, buses, lines, source, gdData);
    const impedanceZ = Math.sqrt(R ** 2 + X ** 2);
    const shortCircuitCurrent = calculateShortCircuitCurrent(R, X, source.nominalVoltage);
    
    return {
      busId: bus.id,
      busName: bus.name,
      impedanceR: R,
      impedanceX: X,
      impedanceZ,
      shortCircuitCurrent,
    };
  });
}

/**
 * Verifica se um equipamento de proteção pode detectar uma falta
 */
export function canDetectFault(
  shortCircuitCurrent: number,
  pickupCurrent: number
): boolean {
  return shortCircuitCurrent >= pickupCurrent;
}

/**
 * Calcula o tempo de atuação de um equipamento (aproximado)
 * Baseado em curvas típicas de proteção
 */
export function calculateOperationTime(
  shortCircuitCurrent: number,
  pickupCurrent: number,
  timeDelay: number
): number | null {
  if (shortCircuitCurrent < pickupCurrent) {
    return null; // Não opera
  }
  
  // Aproximação de curva inversa: t = K / (I/Ip)^n
  const currentRatio = shortCircuitCurrent / pickupCurrent;
  const n = 0.5; // Expoente típico
  const K = timeDelay * (currentRatio ** n);
  
  return Math.max(K, timeDelay * 0.1); // Mínimo de 10% do tempo de delay
}
