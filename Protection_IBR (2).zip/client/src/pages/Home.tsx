import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowRight, Zap, Shield, TrendingUp, BookOpen } from "lucide-react";
import { Link } from "wouter";

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Navigation */}
      <nav className="bg-slate-950/50 backdrop-blur-md border-b border-slate-700 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Zap className="w-6 h-6 text-yellow-400" />
            <span className="text-xl font-bold text-white">Protection IBR</span>
          </div>
          <Link href="/simulator">
            <Button className="bg-yellow-500 hover:bg-yellow-600 text-slate-900 font-semibold">
              Abrir Simulador
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </Link>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="max-w-7xl mx-auto px-6 py-20 space-y-8">
        <div className="space-y-6 text-center">
          <h1 className="text-5xl md:text-6xl font-bold text-white leading-tight">
            Impacto da Geração Distribuída na Proteção de Sistemas Elétricos
          </h1>
          <p className="text-xl text-slate-300 max-w-3xl mx-auto">
            Simule e analise como a inserção de usinas de Geração Distribuída afeta os níveis de curto-circuito e a operação dos equipamentos de proteção em alimentadores radiais
          </p>
          <div className="flex gap-4 justify-center pt-4">
            <Link href="/simulator">
              <Button size="lg" className="bg-yellow-500 hover:bg-yellow-600 text-slate-900 font-semibold">
                Iniciar Simulação
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </Link>
            <Button size="lg" variant="outline" className="border-slate-600 text-white hover:bg-slate-800">
              Saiba Mais
            </Button>
          </div>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-12">
          <Card className="bg-slate-800/50 border-slate-700 backdrop-blur">
            <CardHeader>
              <div className="w-12 h-12 bg-blue-500/20 rounded-lg flex items-center justify-center mb-4">
                <Shield className="w-6 h-6 text-blue-400" />
              </div>
              <CardTitle className="text-white">Análise de Proteção</CardTitle>
            </CardHeader>
            <CardContent className="text-slate-300">
              Verifique quais equipamentos de proteção conseguem detectar faltas em cada barra do alimentador
            </CardContent>
          </Card>

          <Card className="bg-slate-800/50 border-slate-700 backdrop-blur">
            <CardHeader>
              <div className="w-12 h-12 bg-purple-500/20 rounded-lg flex items-center justify-center mb-4">
                <Zap className="w-6 h-6 text-purple-400" />
              </div>
              <CardTitle className="text-white">Simulação Dinâmica</CardTitle>
            </CardHeader>
            <CardContent className="text-slate-300">
              Ative ou desative a GD em tempo real e observe as mudanças nos níveis de curto-circuito instantaneamente
            </CardContent>
          </Card>

          <Card className="bg-slate-800/50 border-slate-700 backdrop-blur">
            <CardHeader>
              <div className="w-12 h-12 bg-green-500/20 rounded-lg flex items-center justify-center mb-4">
                <TrendingUp className="w-6 h-6 text-green-400" />
              </div>
              <CardTitle className="text-white">Visualizações Avançadas</CardTitle>
            </CardHeader>
            <CardContent className="text-slate-300">
              Diagrama do alimentador, tabelas detalhadas e gráficos comparativos para análise completa
            </CardContent>
          </Card>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="bg-slate-800/30 border-y border-slate-700 py-16">
        <div className="max-w-7xl mx-auto px-6 space-y-12">
          <div className="text-center space-y-4">
            <h2 className="text-4xl font-bold text-white">Como Funciona</h2>
            <p className="text-lg text-slate-300">
              Entenda o impacto da Geração Distribuída na proteção de sistemas elétricos
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-6">
              <div className="flex gap-4">
                <div className="flex-shrink-0">
                  <div className="flex items-center justify-center h-10 w-10 rounded-lg bg-yellow-500/20">
                    <span className="text-yellow-400 font-bold">1</span>
                  </div>
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-white">Alimentador Radial</h3>
                  <p className="text-slate-300 mt-1">
                    O sistema começa com um alimentador radial típico, onde a subestação fornece energia através de barras conectadas em série
                  </p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="flex-shrink-0">
                  <div className="flex items-center justify-center h-10 w-10 rounded-lg bg-yellow-500/20">
                    <span className="text-yellow-400 font-bold">2</span>
                  </div>
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-white">Equipamentos de Proteção</h3>
                  <p className="text-slate-300 mt-1">
                    Chaves fusíveis e religadores estão distribuídos ao longo do alimentador para proteger contra faltas
                  </p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="flex-shrink-0">
                  <div className="flex items-center justify-center h-10 w-10 rounded-lg bg-yellow-500/20">
                    <span className="text-yellow-400 font-bold">3</span>
                  </div>
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-white">Inserção de GD</h3>
                  <p className="text-slate-300 mt-1">
                    Quando uma usina de Geração Distribuída é conectada, ela contribui para os níveis de curto-circuito
                  </p>
                </div>
              </div>
            </div>

            <div className="space-y-6">
              <div className="flex gap-4">
                <div className="flex-shrink-0">
                  <div className="flex items-center justify-center h-10 w-10 rounded-lg bg-yellow-500/20">
                    <span className="text-yellow-400 font-bold">4</span>
                  </div>
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-white">Cálculo de Curto-Circuito</h3>
                  <p className="text-slate-300 mt-1">
                    O simulador calcula os níveis de curto-circuito trifásico em cada barra usando o método de impedâncias
                  </p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="flex-shrink-0">
                  <div className="flex items-center justify-center h-10 w-10 rounded-lg bg-yellow-500/20">
                    <span className="text-yellow-400 font-bold">5</span>
                  </div>
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-white">Análise de Proteção</h3>
                  <p className="text-slate-300 mt-1">
                    Verifica se cada equipamento consegue detectar a falta e calcula o tempo de operação
                  </p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="flex-shrink-0">
                  <div className="flex items-center justify-center h-10 w-10 rounded-lg bg-yellow-500/20">
                    <span className="text-yellow-400 font-bold">6</span>
                  </div>
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-white">Visualização de Resultados</h3>
                  <p className="text-slate-300 mt-1">
                    Diagrama, tabelas e gráficos mostram o impacto da GD na proteção do sistema
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Key Concepts Section */}
      <section className="max-w-7xl mx-auto px-6 py-16 space-y-12">
        <div className="text-center space-y-4">
          <h2 className="text-4xl font-bold text-white">Conceitos Principais</h2>
          <p className="text-lg text-slate-300">
            Entenda os termos técnicos utilizados na simulação
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card className="bg-slate-800/50 border-slate-700 backdrop-blur">
            <CardHeader>
              <CardTitle className="text-white text-base">Curto-Circuito (ICC)</CardTitle>
            </CardHeader>
            <CardContent className="text-slate-300 text-sm">
              Corrente que flui quando há uma conexão de baixa impedância entre fases. Medida em Amperes (A) ou quiloamperes (kA). Quanto maior a impedância de Thévenin, menor o ICC.
            </CardContent>
          </Card>

          <Card className="bg-slate-800/50 border-slate-700 backdrop-blur">
            <CardHeader>
              <CardTitle className="text-white text-base">Impedância de Thévenin</CardTitle>
            </CardHeader>
            <CardContent className="text-slate-300 text-sm">
              Impedância equivalente vista de uma barra em direção à fonte. Inclui a impedância da subestação e das linhas até aquela barra.
            </CardContent>
          </Card>

          <Card className="bg-slate-800/50 border-slate-700 backdrop-blur">
            <CardHeader>
              <CardTitle className="text-white text-base">Chave Fusível</CardTitle>
            </CardHeader>
            <CardContent className="text-slate-300 text-sm">
              Equipamento de proteção que abre o circuito quando a corrente excede um valor pré-definido (pickup). Não pode ser rearmed automaticamente.
            </CardContent>
          </Card>

          <Card className="bg-slate-800/50 border-slate-700 backdrop-blur">
            <CardHeader>
              <CardTitle className="text-white text-base">Religador</CardTitle>
            </CardHeader>
            <CardContent className="text-slate-300 text-sm">
              Equipamento de proteção que abre e fecha automaticamente. Permite rearme automático após um tempo pré-definido.
            </CardContent>
          </Card>

          <Card className="bg-slate-800/50 border-slate-700 backdrop-blur">
            <CardHeader>
              <CardTitle className="text-white text-base">Geração Distribuída (GD)</CardTitle>
            </CardHeader>
            <CardContent className="text-slate-300 text-sm">
              Usina de pequeno/médio porte conectada ao alimentador. Contribui para o curto-circuito, alterando a impedância vista pelas barras.
            </CardContent>
          </Card>

          <Card className="bg-slate-800/50 border-slate-700 backdrop-blur">
            <CardHeader>
              <CardTitle className="text-white text-base">Pickup Current</CardTitle>
            </CardHeader>
            <CardContent className="text-slate-300 text-sm">
              Valor de corrente a partir do qual o equipamento de proteção começa a atuar. Deve ser maior que a corrente máxima de carga normal.
            </CardContent>
          </Card>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-gradient-to-r from-yellow-500/10 to-purple-500/10 border-y border-slate-700 py-16">
        <div className="max-w-4xl mx-auto px-6 text-center space-y-6">
          <h2 className="text-3xl font-bold text-white">Pronto para Simular?</h2>
          <p className="text-lg text-slate-300">
            Acesse o simulador interativo e explore o impacto da Geração Distribuída na proteção de sistemas elétricos
          </p>
          <Link href="/simulator">
            <Button size="lg" className="bg-yellow-500 hover:bg-yellow-600 text-slate-900 font-semibold">
              Abrir Simulador
              <ArrowRight className="w-5 h-5 ml-2" />
            </Button>
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-950 border-t border-slate-700 py-8">
        <div className="max-w-7xl mx-auto px-6 text-center text-slate-400 text-sm">
          <p>
            Protection IBR - Simulador de Impacto da Geração Distribuída na Proteção de Sistemas Elétricos
          </p>
          <p className="mt-2">
            Desenvolvido para análise educacional e técnica de sistemas de proteção
          </p>
        </div>
      </footer>
    </div>
  );
}
