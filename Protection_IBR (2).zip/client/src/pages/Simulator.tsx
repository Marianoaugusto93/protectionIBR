import React, { useState, useEffect } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Loader2, AlertCircle, Zap, Settings } from "lucide-react";
import FeederDiagram from "@/components/FeederDiagram";
import ShortCircuitTable from "@/components/ShortCircuitTable";
import ComparisonChart from "@/components/ComparisonChart";
import AdvancedControls from "@/components/AdvancedControls";
import ProtectionFailureAnalysis from "@/components/ProtectionFailureAnalysis";
import { ExportPDFButton } from "@/components/ExportPDFButton";

const DEFAULT_FEEDER_ID = 1;

interface SimulationState {
  gdId?: number;
  gdActive: boolean;
  gdCapacity: number;
  sourceImpedanceR: number;
  devicePickupCurrents: Record<number, number>;
  resultsWithoutGD: any[];
  resultsWithGD: any[];
  loading: boolean;
  error?: string;
  showAdvanced: boolean;
}

export default function Simulator() {
  const [state, setState] = useState<SimulationState>({
    gdActive: false,
    gdCapacity: 500,
    sourceImpedanceR: 0.1,
    devicePickupCurrents: {},
    resultsWithoutGD: [],
    resultsWithGD: [],
    loading: true,
    showAdvanced: false,
  });

  // Queries
  const feedersQuery = trpc.feeder.list.useQuery();
  const busesQuery = trpc.bus.listByFeeder.useQuery(
    { feederId: DEFAULT_FEEDER_ID },
    { enabled: !!DEFAULT_FEEDER_ID }
  );
  const protectionDevicesQuery = trpc.protectionDevice.listByFeeder.useQuery(
    { feederId: DEFAULT_FEEDER_ID },
    { enabled: !!DEFAULT_FEEDER_ID }
  );
  const gdQuery = trpc.distributedGeneration.listByFeeder.useQuery(
    { feederId: DEFAULT_FEEDER_ID },
    { enabled: !!DEFAULT_FEEDER_ID }
  );

  // Simulation queries
  const simulationWithoutGDQuery = trpc.simulation.calculateShortCircuits.useQuery(
    {
      feederId: DEFAULT_FEEDER_ID,
      gdActive: false,
    },
    { enabled: !!DEFAULT_FEEDER_ID }
  );

  const simulationWithGDQuery = trpc.simulation.calculateShortCircuits.useQuery(
    {
      feederId: DEFAULT_FEEDER_ID,
      gdId: state.gdId,
      gdActive: state.gdActive && !!state.gdId,
    },
    { enabled: !!DEFAULT_FEEDER_ID && !!state.gdId }
  );

  // Toggle GD
  const toggleGDMutation = trpc.distributedGeneration.toggleStatus.useMutation({
    onSuccess: () => {
      gdQuery.refetch();
    },
  });

  // Initialize
  useEffect(() => {
    if (gdQuery.data && gdQuery.data.length > 0) {
      const firstGD = gdQuery.data[0];
      setState(prev => ({
        ...prev,
        gdId: firstGD.id,
        gdActive: firstGD.isActive,
        gdCapacity: firstGD.capacity,
      }));
    }
  }, [gdQuery.data]);

  // Update results
  useEffect(() => {
    if (simulationWithoutGDQuery.data) {
      setState(prev => ({
        ...prev,
        resultsWithoutGD: simulationWithoutGDQuery.data || [],
      }));
    }
  }, [simulationWithoutGDQuery.data]);

  useEffect(() => {
    if (simulationWithGDQuery.data) {
      setState(prev => ({
        ...prev,
        resultsWithGD: simulationWithGDQuery.data || [],
      }));
    }
  }, [simulationWithGDQuery.data]);

  const handleToggleGD = async () => {
    if (!state.gdId) return;

    try {
      await toggleGDMutation.mutateAsync({
        gdId: state.gdId,
        isActive: !state.gdActive,
      });

      setState(prev => ({
        ...prev,
        gdActive: !prev.gdActive,
      }));
    } catch (error) {
      console.error("Erro ao alternar GD:", error);
      setState(prev => ({
        ...prev,
        error: "Erro ao alternar status da GD",
      }));
    }
  };

  const isLoading =
    feedersQuery.isLoading ||
    busesQuery.isLoading ||
    protectionDevicesQuery.isLoading ||
    gdQuery.isLoading ||
    simulationWithoutGDQuery.isLoading ||
    (state.gdActive && simulationWithGDQuery.isLoading);

  const gdUnit = gdQuery.data?.[0];
  const comparisonData = state.resultsWithoutGD.map((resultWithout) => {
    const resultWith = state.resultsWithGD.find(r => r.busId === resultWithout.busId);
    const iccWithGD = resultWith?.shortCircuitCurrent || resultWithout.shortCircuitCurrent;
    const iccWithoutGD = resultWithout.shortCircuitCurrent;
    const difference = iccWithGD - iccWithoutGD;
    const percentageChange = iccWithoutGD > 0 ? (difference / iccWithoutGD) * 100 : 0;

    return {
      busName: resultWithout.busName,
      iccWithoutGD,
      iccWithGD,
      difference,
      percentageChange,
    };
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="space-y-2">
          <h1 className="text-4xl font-bold text-slate-900">
            Simulador de Geração Distribuída
          </h1>
          <p className="text-lg text-slate-600">
            Analise o impacto da GD na proteção de alimentadores radiais com controles avançados
          </p>
        </div>

        {/* Error Message */}
        {state.error && (
          <Card className="border-red-200 bg-red-50">
            <CardContent className="pt-6 flex gap-3">
              <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0" />
              <p className="text-red-800">{state.error}</p>
            </CardContent>
          </Card>
        )}

        {/* GD Control Card */}
        {gdUnit && (
          <Card className="bg-white shadow-md">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Zap className="w-5 h-5 text-purple-600" />
                Controle de Geração Distribuída
              </CardTitle>
              <CardDescription>
                {gdUnit.name} - {state.gdCapacity} kW
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg border border-slate-200">
                <div className="space-y-1">
                  <p className="font-semibold text-slate-900">Status da GD</p>
                  <p className="text-sm text-slate-600">
                    Clique para ligar ou desligar a usina
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <Badge variant={state.gdActive ? "default" : "secondary"}>
                    {state.gdActive ? "ATIVA" : "INATIVA"}
                  </Badge>
                  <Switch
                    checked={state.gdActive}
                    onCheckedChange={handleToggleGD}
                    disabled={toggleGDMutation.isPending}
                  />
                </div>
              </div>

              {toggleGDMutation.isPending && (
                <div className="flex items-center gap-2 text-sm text-slate-600">
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Atualizando...
                </div>
              )}

              <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 text-sm">
              <p className="text-blue-900">
                <strong>Controles Avançados:</strong> Ajuste a capacidade da GD, força da fonte e sensibilidade dos equipamentos para explorar cenários de falha de proteção
              </p>
            </div>

            <Button
              variant={state.showAdvanced ? "default" : "outline"}
              className="w-full flex items-center gap-2"
              onClick={() => setState(prev => ({ ...prev, showAdvanced: !prev.showAdvanced }))}
            >
              <Settings className="w-4 h-4" />
              {state.showAdvanced ? "Ocultar" : "Mostrar"} Controles Avançados
            </Button>
            </CardContent>
          </Card>
        )}

        {/* Advanced Controls */}
        {state.showAdvanced && protectionDevicesQuery.data && (
          <AdvancedControls
            gdCapacity={state.gdCapacity}
            onGDCapacityChange={(capacity) => setState(prev => ({ ...prev, gdCapacity: capacity }))}
            sourceImpedanceR={state.sourceImpedanceR}
            onSourceImpedanceChange={(impedance) => setState(prev => ({ ...prev, sourceImpedanceR: impedance }))}
            devicePickupCurrents={state.devicePickupCurrents}
            onDevicePickupChange={(deviceId, pickup) => {
              setState(prev => ({
                ...prev,
                devicePickupCurrents: { ...prev.devicePickupCurrents, [deviceId]: pickup },
              }));
            }}
            protectionDevices={protectionDevicesQuery.data.map(d => ({
              id: d.id,
              name: d.name,
              type: d.type,
              pickupCurrent: parseFloat(d.pickupCurrent.toString()),
            }))}
          />
        )}

        {/* Loading State */}
        {isLoading && (
          <Card className="bg-white shadow-md">
            <CardContent className="pt-6 flex items-center justify-center gap-3 py-12">
              <Loader2 className="w-6 h-6 animate-spin text-slate-600" />
              <p className="text-slate-600">Carregando simulação...</p>
            </CardContent>
          </Card>
        )}

        {/* Diagram */}
        {!isLoading && busesQuery.data && (
          <Card className="bg-white shadow-md">
            <CardHeader>
              <CardTitle>Diagrama do Alimentador Radial</CardTitle>
              <CardDescription>
                Visualize o alimentador com os níveis de curto-circuito
                {state.gdActive && " (Com GD Ativa)"}
                {!state.gdActive && " (Sem GD)"}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <FeederDiagram
                buses={busesQuery.data.map(bus => ({
                  ...bus,
                  shortCircuitCurrent: state.gdActive
                    ? state.resultsWithGD.find(r => r.busId === bus.id)?.shortCircuitCurrent
                    : state.resultsWithoutGD.find(r => r.busId === bus.id)?.shortCircuitCurrent,
                }))}
                protectionDevices={protectionDevicesQuery.data || []}
                gdUnits={gdQuery.data || []}
                selectedGDId={state.gdId}
              />
            </CardContent>
          </Card>
        )}

        {/* Protection Failure Analysis */}
        {!isLoading && state.resultsWithGD.length > 0 && state.gdActive && (
          <ProtectionFailureAnalysis
            results={state.resultsWithGD}
            gdActive={state.gdActive}
            sourceImpedanceR={state.sourceImpedanceR}
          />
        )}

        {/* Results Comparison */}
        {!isLoading && state.resultsWithoutGD.length > 0 && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Without GD */}
            <Card className="bg-white shadow-md">
              <CardHeader>
                <CardTitle className="text-base">Sem Geração Distribuída</CardTitle>
              </CardHeader>
              <CardContent>
                <ShortCircuitTable results={state.resultsWithoutGD} withGD={false} />
              </CardContent>
            </Card>

            {/* With GD */}
            {state.gdActive && state.resultsWithGD.length > 0 && (
              <Card className="bg-white shadow-md">
                <CardHeader>
                  <CardTitle className="text-base">Com Geração Distribuída</CardTitle>
                </CardHeader>
                <CardContent>
                  <ShortCircuitTable results={state.resultsWithGD} withGD={true} />
                </CardContent>
              </Card>
            )}
          </div>
        )}

        {/* Comparison Chart */}
        {!isLoading && state.gdActive && comparisonData.length > 0 && (
          <Card className="bg-white shadow-md">
            <CardHeader>
              <CardTitle>Análise Comparativa</CardTitle>
              <CardDescription>
                Comparação de níveis de curto-circuito com e sem GD
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ComparisonChart
                data={comparisonData}
                title="Impacto da Geração Distribuída nos Níveis de Curto-Circuito"
              />
            </CardContent>
          </Card>
        )}

        {/* Export PDF Button */}
        {!isLoading && state.resultsWithoutGD.length > 0 && (
          <Card className="bg-white shadow-md">
            <CardHeader>
              <CardTitle>Exportar Análise</CardTitle>
              <CardDescription>
                Gere um relatório detalhado em PDF com todos os resultados e recomendações
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ExportPDFButton
                feederName={feedersQuery.data?.[0]?.name || "Alimentador 1"}
                gdActive={state.gdActive}
                gdName={gdUnit?.name}
                gdCapacity={state.gdCapacity}
                sourceImpedanceR={state.sourceImpedanceR}
                resultsWithoutGD={state.resultsWithoutGD}
                resultsWithGD={state.resultsWithGD}
                failures={[]}
                blindingRisk={false}
                coordinationIssues={false}
              />
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
