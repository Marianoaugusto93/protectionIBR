import React from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { AlertCircle, CheckCircle, XCircle } from "lucide-react";

interface ProtectionDevice {
  id: number;
  name: string;
  type: "fuse" | "recloser";
  pickupCurrent: number;
  timeDelay: number;
  canDetect?: boolean;
  operationTime?: number | null;
}

interface ShortCircuitResult {
  busId: number;
  busName: string;
  impedanceR: number;
  impedanceX: number;
  impedanceZ: number;
  shortCircuitCurrent: number;
  protectionDevices?: ProtectionDevice[];
}

interface ShortCircuitTableProps {
  results: ShortCircuitResult[];
  withGD: boolean;
}

export default function ShortCircuitTable({
  results,
  withGD,
}: ShortCircuitTableProps) {
  const formatCurrent = (current: number) => {
    if (current >= 1000) {
      return `${(current / 1000).toFixed(2)} kA`;
    }
    return `${current.toFixed(0)} A`;
  };

  const formatImpedance = (value: number) => {
    return `${value.toFixed(4)} Ω`;
  };

  const getImpedanceColor = (impedance: number) => {
    if (impedance < 0.2) return "text-red-600";
    if (impedance < 0.5) return "text-orange-600";
    return "text-green-600";
  };

  const getDetectionStatus = (device: ProtectionDevice) => {
    if (!device.canDetect) {
      return (
        <div className="flex items-center gap-1">
          <XCircle className="w-4 h-4 text-red-600" />
          <span className="text-xs">Não detecta</span>
        </div>
      );
    }
    return (
      <div className="flex items-center gap-1">
        <CheckCircle className="w-4 h-4 text-green-600" />
        <span className="text-xs">Detecta</span>
      </div>
    );
  };

  return (
    <div className="w-full space-y-4">
      <div className="flex items-center gap-2 mb-4">
        <h3 className="text-lg font-semibold">
          Resultados de Curto-Circuito
          {withGD && <Badge className="ml-2">Com GD</Badge>}
          {!withGD && <Badge variant="outline" className="ml-2">Sem GD</Badge>}
        </h3>
      </div>

      <div className="border border-border rounded-lg overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow className="bg-muted">
              <TableHead className="font-semibold">Barra</TableHead>
              <TableHead className="text-right font-semibold">ICC (kA)</TableHead>
              <TableHead className="text-right font-semibold">Z (Ω)</TableHead>
              <TableHead className="text-right font-semibold">R (Ω)</TableHead>
              <TableHead className="text-right font-semibold">X (Ω)</TableHead>
              <TableHead className="font-semibold">Proteção</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {results.map((result) => (
              <React.Fragment key={result.busId}>
                <TableRow className="hover:bg-muted/50">
                  <TableCell className="font-medium">{result.busName}</TableCell>
                  <TableCell className="text-right font-semibold">
                    <span className={getImpedanceColor(result.impedanceZ)}>
                      {(result.shortCircuitCurrent / 1000).toFixed(2)}
                    </span>
                  </TableCell>
                  <TableCell className="text-right">
                    {formatImpedance(result.impedanceZ)}
                  </TableCell>
                  <TableCell className="text-right">
                    {formatImpedance(result.impedanceR)}
                  </TableCell>
                  <TableCell className="text-right">
                    {formatImpedance(result.impedanceX)}
                  </TableCell>
                  <TableCell>
                    {result.protectionDevices && result.protectionDevices.length > 0 ? (
                      <div className="flex flex-wrap gap-1">
                        {result.protectionDevices.map((device) => (
                          <Badge
                            key={device.id}
                            variant={device.canDetect ? "default" : "secondary"}
                            className="text-xs"
                            title={`${device.name} - ${device.type === "fuse" ? "Fusível" : "Religador"}`}
                          >
                            {device.canDetect ? "✓" : "✗"} {device.name}
                          </Badge>
                        ))}
                      </div>
                    ) : (
                      <span className="text-xs text-muted-foreground">Nenhum</span>
                    )}
                  </TableCell>
                </TableRow>

                {/* Detalhes dos equipamentos de proteção */}
                {result.protectionDevices && result.protectionDevices.length > 0 && (
                  <TableRow className="bg-muted/30">
                    <TableCell colSpan={6} className="p-3">
                      <div className="space-y-2">
                        {result.protectionDevices.map((device) => (
                          <div
                            key={device.id}
                            className="flex items-center justify-between text-sm bg-white p-2 rounded border border-border"
                          >
                            <div className="flex-1">
                              <span className="font-medium">{device.name}</span>
                              <span className="text-xs text-muted-foreground ml-2">
                                ({device.type === "fuse" ? "Fusível" : "Religador"})
                              </span>
                            </div>
                            <div className="flex items-center gap-3 text-xs">
                              <span>
                                Pickup: {formatCurrent(device.pickupCurrent)}
                              </span>
                              <span>
                                Delay: {device.timeDelay.toFixed(3)}s
                              </span>
                              {device.operationTime !== null && (
                                <span className="font-semibold">
                                  Op: {device.operationTime?.toFixed(3)}s
                                </span>
                              )}
                              {getDetectionStatus(device)}
                            </div>
                          </div>
                        ))}
                      </div>
                    </TableCell>
                  </TableRow>
                )}
              </React.Fragment>
            ))}
          </TableBody>
        </Table>
      </div>

      <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 text-sm">
        <div className="flex gap-2">
          <AlertCircle className="w-4 h-4 text-blue-600 flex-shrink-0 mt-0.5" />
          <div>
            <p className="font-semibold text-blue-900">Interpretação dos Resultados:</p>
            <ul className="text-blue-800 mt-1 space-y-1 text-xs">
              <li>
                • <strong>ICC (kA):</strong> Nível de curto-circuito trifásico na barra
              </li>
              <li>
                • <strong>Z (Ω):</strong> Impedância de Thévenin vista da barra
              </li>
              <li>
                • <strong>Proteção:</strong> Equipamentos que conseguem detectar a falta
              </li>
              <li>
                • <strong>Op:</strong> Tempo de operação do equipamento de proteção
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
