import React from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  LineChart,
  Line,
} from "recharts";

interface ComparisonData {
  busName: string;
  iccWithoutGD: number;
  iccWithGD: number;
  difference: number;
  percentageChange: number;
}

interface ComparisonChartProps {
  data: ComparisonData[];
  title: string;
}

export default function ComparisonChart({ data, title }: ComparisonChartProps) {
  const chartData = data.map(item => ({
    name: item.busName,
    "Sem GD (kA)": item.iccWithoutGD / 1000,
    "Com GD (kA)": item.iccWithGD / 1000,
    "Variação (%)": item.percentageChange,
  }));

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-2 border border-border rounded shadow-lg text-sm">
          <p className="font-semibold">{label}</p>
          {payload.map((entry: any, index: number) => (
            <p key={index} style={{ color: entry.color }}>
              {entry.name}: {entry.value.toFixed(2)}
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  return (
    <div className="w-full space-y-4">
      <h3 className="text-lg font-semibold">{title}</h3>

      <div className="border border-border rounded-lg p-4 bg-white">
        <ResponsiveContainer width="100%" height={400}>
          <BarChart data={chartData} margin={{ top: 20, right: 30, left: 0, bottom: 60 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
            <XAxis
              dataKey="name"
              angle={-45}
              textAnchor="end"
              height={100}
              tick={{ fontSize: 12 }}
            />
            <YAxis
              label={{ value: "ICC (kA)", angle: -90, position: "insideLeft" }}
              tick={{ fontSize: 12 }}
            />
            <Tooltip content={<CustomTooltip />} />
            <Legend />
            <Bar dataKey="Sem GD (kA)" fill="#3b82f6" radius={[8, 8, 0, 0]} />
            <Bar dataKey="Com GD (kA)" fill="#8b5cf6" radius={[8, 8, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>

      <div className="border border-border rounded-lg p-4 bg-white">
        <h4 className="text-sm font-semibold mb-3">Variação Percentual (%)</h4>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={chartData} margin={{ top: 20, right: 30, left: 0, bottom: 60 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
            <XAxis
              dataKey="name"
              angle={-45}
              textAnchor="end"
              height={100}
              tick={{ fontSize: 12 }}
            />
            <YAxis
              label={{ value: "Variação (%)", angle: -90, position: "insideLeft" }}
              tick={{ fontSize: 12 }}
            />
            <Tooltip content={<CustomTooltip />} />
            <Line
              type="monotone"
              dataKey="Variação (%)"
              stroke="#f97316"
              strokeWidth={2}
              dot={{ fill: "#f97316", r: 4 }}
              activeDot={{ r: 6 }}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>

      <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 text-sm">
        <p className="font-semibold text-amber-900 mb-2">Análise da Comparação:</p>
        <ul className="text-amber-800 space-y-1 text-xs">
          <li>
            • A inserção de GD <strong>aumenta</strong> os níveis de curto-circuito nas barras onde está conectada
          </li>
          <li>
            • Barras mais próximas da GD sofrem maior impacto na proteção
          </li>
          <li>
            • Equipamentos de proteção podem precisar de reajustes com a GD ativa
          </li>
          <li>
            • A variação percentual mostra o impacto relativo em cada barra
          </li>
        </ul>
      </div>
    </div>
  );
}
