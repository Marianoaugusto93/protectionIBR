import React from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle, AlertCircle, CheckCircle, XCircle } from "lucide-react";

interface ProtectionDevice {
  id: number;
  name: string;
  type: "fuse" | "recloser";
  pickupCurrent: number;
  canDetect?: boolean;
  operationTime?: number | null;
}

interface ShortCircuitResult {
  busId: number;
  busName: string;
  shortCircuitCurrent: number;
  protectionDevices?: ProtectionDevice[];
}

interface ProtectionFailureAnalysisProps {
  results: ShortCircuitResult[];
  gdActive: boolean;
  sourceImpedanceR: number;
}

export default function ProtectionFailureAnalysis({
  results,
  gdActive,
  sourceImpedanceR,
}: ProtectionFailureAnalysisProps) {
  // Analisar falhas de proteção
  const failures = results.flatMap((result) => {
    const failures: any[] = [];

    if (!result.protectionDevices) return failures;

    result.protectionDevices.forEach((device) => {
      if (!device.canDetect) {
        failures.push({
          type: "no_detection",
          busName: result.busName,
          deviceName: device.name,
          deviceType: device.type,
          icc: result.shortCircuitCurrent,
          pickup: device.pickupCurrent,
          severity: "high",
        });
      } else if (device.operationTime && device.operationTime > 1.0) {
        failures.push({
          type: "slow_operation",
          busName: result.busName,
          deviceName: device.name,
          deviceType: device.type,
          operationTime: device.operationTime,
          severity: "medium",
        });
      }
    });

    return failures;
  });

  // Detectar blinding (GD reduz ICC)
  const blindingRisk = gdActive && sourceImpedanceR > 0.15;

  // Detectar falta de coordenação
  const coordinationIssues = results.some((result) => {
    if (!result.protectionDevices || result.protectionDevices.length < 2) return false;

    const detectingDevices = result.protectionDevices.filter(d => d.canDetect);
    return detectingDevices.length > 1;
  });

  const hasIssues = failures.length > 0 || blindingRisk || coordinationIssues;

  return (
    <div className="space-y-4">
      {/* Summary Card */}
      <Card className={hasIssues ? "bg-red-50 border-red-200" : "bg-green-50 border-green-200"}>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            {hasIssues ? (
              <>
                <AlertTriangle className="w-5 h-5 text-red-600" />
                Problemas de Proteção Detectados
              </>
            ) : (
              <>
                <CheckCircle className="w-5 h-5 text-green-600" />
                Proteção Operando Corretamente
              </>
            )}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {failures.length > 0 && (
              <div className="flex items-start gap-2">
                <XCircle className="w-4 h-4 text-red-600 mt-0.5 flex-shrink-0" />
                <span className={hasIssues ? "text-red-900" : "text-green-900"}>
                  {failures.length} equipamento(s) com falha de detecção
                </span>
              </div>
            )}
            {blindingRisk && (
              <div className="flex items-start gap-2">
                <AlertCircle className="w-4 h-4 text-orange-600 mt-0.5 flex-shrink-0" />
                <span className="text-orange-900">
                  Risco de blinding: Fonte fraca + GD pode reduzir ICC
                </span>
              </div>
            )}
            {coordinationIssues && (
              <div className="flex items-start gap-2">
                <AlertCircle className="w-4 h-4 text-orange-600 mt-0.5 flex-shrink-0" />
                <span className="text-orange-900">
                  Possível falta de coordenação: múltiplos equipamentos podem atuar
                </span>
              </div>
            )}
            {!hasIssues && (
              <div className="text-green-900">
                Todos os equipamentos conseguem detectar faltas e estão coordenados
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Detailed Failures */}
      {failures.length > 0 && (
        <Card className="bg-white shadow-md">
          <CardHeader>
            <CardTitle className="text-base">Detalhes das Falhas</CardTitle>
            <CardDescription>
              Equipamentos que não conseguem detectar faltas ou têm atuação lenta
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {failures.map((failure, idx) => (
              <div key={idx} className="border border-red-200 bg-red-50 rounded-lg p-3 space-y-2">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="font-semibold text-red-900">{failure.deviceName}</p>
                    <p className="text-sm text-red-800">
                      Barra: <strong>{failure.busName}</strong>
                    </p>
                  </div>
                  <Badge variant="destructive" className="text-xs">
                    {failure.type === "no_detection" ? "Não Detecta" : "Atuação Lenta"}
                  </Badge>
                </div>

                {failure.type === "no_detection" && (
                  <div className="bg-white rounded p-2 text-sm space-y-1">
                    <div className="flex justify-between">
                      <span className="text-red-700">ICC na barra:</span>
                      <span className="font-semibold text-red-900">
                        {(failure.icc / 1000).toFixed(2)} kA
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-red-700">Pickup do equipamento:</span>
                      <span className="font-semibold text-red-900">
                        {failure.pickup.toFixed(0)} A
                      </span>
                    </div>
                    <div className="flex justify-between text-red-600">
                      <span>Diferença:</span>
                      <span className="font-semibold">
                        {(failure.pickup - failure.icc).toFixed(0)} A (ICC menor que pickup)
                      </span>
                    </div>
                  </div>
                )}

                {failure.type === "slow_operation" && (
                  <div className="bg-white rounded p-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-orange-700">Tempo de operação:</span>
                      <span className="font-semibold text-orange-900">
                        {failure.operationTime?.toFixed(3)} s
                      </span>
                    </div>
                    <p className="text-xs text-orange-600 mt-1">
                      Atuação lenta pode permitir danos ao equipamento
                    </p>
                  </div>
                )}

                <div className="bg-white rounded p-2 text-xs text-red-700 space-y-1">
                  <p className="font-semibold">Ações recomendadas:</p>
                  <ul className="space-y-1">
                    {failure.type === "no_detection" && (
                      <>
                        <li>• Reduzir pickup current do equipamento</li>
                        <li>• Aumentar a força da fonte (reduzir impedância)</li>
                        <li>• Reposicionar equipamento mais próximo da falta</li>
                        <li>• Adicionar equipamento de proteção adicional</li>
                      </>
                    )}
                    {failure.type === "slow_operation" && (
                      <>
                        <li>• Reduzir time delay do equipamento</li>
                        <li>• Verificar coordenação com outros equipamentos</li>
                        <li>• Considerar religador em vez de fusível</li>
                      </>
                    )}
                  </ul>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* Risk Assessment */}
      <Card className="bg-white shadow-md">
        <CardHeader>
          <CardTitle className="text-base">Avaliação de Riscos</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <div
                className={`w-3 h-3 rounded-full ${
                  blindingRisk ? "bg-red-500" : "bg-green-500"
                }`}
              />
              <span className="text-sm">
                <strong>Blinding (Proteção Cega):</strong>{" "}
                {blindingRisk
                  ? "Risco alto - Fonte fraca pode não fornecer ICC suficiente"
                  : "Risco baixo"}
              </span>
            </div>

            <div className="flex items-center gap-2">
              <div
                className={`w-3 h-3 rounded-full ${
                  coordinationIssues ? "bg-orange-500" : "bg-green-500"
                }`}
              />
              <span className="text-sm">
                <strong>Coordenação:</strong>{" "}
                {coordinationIssues
                  ? "Risco médio - Múltiplos equipamentos podem atuar simultaneamente"
                  : "Risco baixo"}
              </span>
            </div>

            <div className="flex items-center gap-2">
              <div
                className={`w-3 h-3 rounded-full ${
                  failures.length > 0 ? "bg-red-500" : "bg-green-500"
                }`}
              />
              <span className="text-sm">
                <strong>Detecção de Faltas:</strong>{" "}
                {failures.length > 0
                  ? `Risco alto - ${failures.length} equipamento(s) não detectam`
                  : "Risco baixo"}
              </span>
            </div>
          </div>

          <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 text-sm">
            <p className="font-semibold text-blue-900 mb-1">Dica:</p>
            <p className="text-blue-800">
              Ajuste os parâmetros acima para explorar diferentes cenários e entender como a GD afeta a proteção do sistema
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
