import React from "react";
import { AlertCircle, Zap } from "lucide-react";

interface Bus {
  id: number;
  name: string;
  position: number;
  shortCircuitCurrent?: number;
}

interface ProtectionDevice {
  id: number;
  name: string;
  type: "fuse" | "recloser";
  busId: number;
  canDetect?: boolean;
}

interface GD {
  id: number;
  name: string;
  busId: number;
  isActive: boolean;
}

interface FeederDiagramProps {
  buses: Bus[];
  protectionDevices: ProtectionDevice[];
  gdUnits: GD[];
  selectedGDId?: number;
}

export default function FeederDiagram({
  buses,
  protectionDevices,
  gdUnits,
  selectedGDId,
}: FeederDiagramProps) {
  const svgWidth = 1200;
  const svgHeight = 400;
  const padding = 60;
  const busRadius = 20;

  // Calcular posições das barras no eixo X
  const maxPosition = Math.max(...buses.map(b => b.position), 1);
  const busSpacing = (svgWidth - 2 * padding) / maxPosition;

  const getBusX = (position: number) => padding + position * busSpacing;
  const getBusY = () => svgHeight / 2;

  // Encontrar barra da subestação (posição 0)
  const substationBus = buses.find(b => b.position === 0);

  return (
    <div className="w-full bg-white border border-border rounded-lg p-4 overflow-x-auto">
      <svg width={svgWidth} height={svgHeight} className="mx-auto">
        {/* Linha principal do alimentador */}
        <line
          x1={getBusX(0)}
          y1={getBusY()}
          x2={getBusX(maxPosition)}
          y2={getBusY()}
          stroke="#666"
          strokeWidth={3}
        />

        {/* Desenhar barras */}
        {buses.map((bus) => {
          const x = getBusX(bus.position);
          const y = getBusY();
          const isSubstation = bus.position === 0;
          const iccLevel = bus.shortCircuitCurrent || 0;
          const iccColor = iccLevel > 50000 ? "#ef4444" : iccLevel > 20000 ? "#f97316" : "#22c55e";

          return (
            <g key={bus.id}>
              {/* Círculo da barra */}
              <circle
                cx={x}
                cy={y}
                r={busRadius}
                fill={isSubstation ? "#3b82f6" : iccColor}
                stroke="#000"
                strokeWidth={2}
              />

              {/* Ícone de subestação */}
              {isSubstation && (
                <text
                  x={x}
                  y={y}
                  textAnchor="middle"
                  dy="0.3em"
                  fontSize="16"
                  fontWeight="bold"
                  fill="white"
                >
                  S
                </text>
              )}

              {/* Nome da barra */}
              <text
                x={x}
                y={y + busRadius + 25}
                textAnchor="middle"
                fontSize="12"
                fontWeight="500"
              >
                {bus.name}
              </text>

              {/* Nível de curto-circuito */}
              {!isSubstation && iccLevel > 0 && (
                <text
                  x={x}
                  y={y - busRadius - 15}
                  textAnchor="middle"
                  fontSize="11"
                  fill="#666"
                >
                  {(iccLevel / 1000).toFixed(1)} kA
                </text>
              )}
            </g>
          );
        })}

        {/* Desenhar equipamentos de proteção */}
        {protectionDevices.map((device) => {
          const bus = buses.find(b => b.id === device.busId);
          if (!bus) return null;

          const x = getBusX(bus.position);
          const y = getBusY();
          const offsetY = device.type === "fuse" ? -50 : -70;
          const deviceColor = device.canDetect ? "#22c55e" : "#94a3b8";

          return (
            <g key={device.id}>
              {/* Símbolo do equipamento */}
              {device.type === "fuse" ? (
                <>
                  {/* Chave fusível */}
                  <rect
                    x={x - 8}
                    y={y + offsetY}
                    width={16}
                    height={20}
                    fill={deviceColor}
                    stroke="#000"
                    strokeWidth={1}
                  />
                  <line
                    x1={x}
                    y1={y - busRadius}
                    x2={x}
                    y2={y + offsetY + 20}
                    stroke="#666"
                    strokeWidth={1}
                  />
                </>
              ) : (
                <>
                  {/* Religador */}
                  <circle
                    cx={x}
                    cy={y + offsetY}
                    r={10}
                    fill={deviceColor}
                    stroke="#000"
                    strokeWidth={1}
                  />
                  <line
                    x1={x}
                    y1={y - busRadius}
                    x2={x}
                    y2={y + offsetY - 10}
                    stroke="#666"
                    strokeWidth={1}
                  />
                </>
              )}

              {/* Nome do equipamento */}
              <text
                x={x}
                y={y + offsetY + 35}
                textAnchor="middle"
                fontSize="10"
                fill="#666"
              >
                {device.name}
              </text>

              {/* Indicador de detecção */}
              {device.canDetect && (
                <circle
                  cx={x + 15}
                  cy={y + offsetY}
                  r={5}
                  fill="#22c55e"
                  opacity={0.7}
                />
              )}
            </g>
          );
        })}

        {/* Desenhar Geração Distribuída */}
        {gdUnits.map((gd) => {
          const bus = buses.find(b => b.id === gd.busId);
          if (!bus) return null;

          const x = getBusX(bus.position);
          const y = getBusY();
          const offsetY = 50;
          const gdColor = gd.isActive ? "#8b5cf6" : "#cbd5e1";

          return (
            <g key={gd.id} opacity={gd.isActive ? 1 : 0.5}>
              {/* Símbolo de gerador */}
              <circle
                cx={x}
                cy={y + offsetY}
                r={12}
                fill={gdColor}
                stroke="#000"
                strokeWidth={1}
              />
              <line
                x1={x - 4}
                y1={y + offsetY}
                x2={x + 4}
                y2={y + offsetY}
                stroke="#000"
                strokeWidth={1}
              />
              <line
                x1={x}
                y1={y + busRadius}
                x2={x}
                y2={y + offsetY - 12}
                stroke="#666"
                strokeWidth={1}
              />

              {/* Nome da GD */}
              <text
                x={x}
                y={y + offsetY + 30}
                textAnchor="middle"
                fontSize="10"
                fontWeight="500"
                fill={gd.isActive ? "#8b5cf6" : "#94a3b8"}
              >
                {gd.name}
              </text>

              {/* Indicador de status */}
              {gd.isActive && (
                <circle
                  cx={x + 18}
                  cy={y + offsetY - 8}
                  r={4}
                  fill="#fbbf24"
                  opacity={0.8}
                />
              )}
            </g>
          );
        })}

        {/* Legenda */}
        <g>
          <text x={padding} y={svgHeight - 15} fontSize="11" fontWeight="bold">
            Legenda:
          </text>
          <circle cx={padding + 70} cy={svgHeight - 20} r={6} fill="#ef4444" />
          <text x={padding + 85} y={svgHeight - 15} fontSize="10">
            ICC Alto (&gt;50kA)
          </text>
          <circle cx={padding + 200} cy={svgHeight - 20} r={6} fill="#f97316" />
          <text x={padding + 215} y={svgHeight - 15} fontSize="10">
            ICC Médio (20-50kA)
          </text>
          <circle cx={padding + 330} cy={svgHeight - 20} r={6} fill="#22c55e" />
          <text x={padding + 345} y={svgHeight - 15} fontSize="10">
            ICC Baixo (&lt;20kA)
          </text>
        </g>
      </svg>
    </div>
  );
}
