import { Button } from "@/components/ui/button";
import { Download, Loader2 } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

interface ExportPDFButtonProps {
  feederName: string;
  gdActive: boolean;
  gdName?: string;
  gdCapacity?: number;
  sourceImpedanceR: number;
  resultsWithoutGD: Array<{
    busId: number;
    busName: string;
    shortCircuitCurrent: number;
    impedanceR: number;
    impedanceX: number;
    impedanceTotal: number;
    protectionDevices?: Array<{
      id: number;
      name: string;
      type: "fuse" | "recloser";
      pickupCurrent: number;
      canDetect?: boolean;
      operationTime?: number | null;
    }>;
  }>;
  resultsWithGD: Array<{
    busId: number;
    busName: string;
    shortCircuitCurrent: number;
    impedanceR: number;
    impedanceX: number;
    impedanceTotal: number;
    protectionDevices?: Array<{
      id: number;
      name: string;
      type: "fuse" | "recloser";
      pickupCurrent: number;
      canDetect?: boolean;
      operationTime?: number | null;
    }>;
  }>;
  failures: Array<{
    type: "no_detection" | "slow_operation";
    busName: string;
    deviceName: string;
    deviceType: "fuse" | "recloser";
    icc?: number;
    pickup?: number;
    operationTime?: number;
    severity: "high" | "medium";
  }>;
  blindingRisk: boolean;
  coordinationIssues: boolean;
}

export function ExportPDFButton({
  feederName,
  gdActive,
  gdName,
  gdCapacity,
  sourceImpedanceR,
  resultsWithoutGD,
  resultsWithGD,
  failures,
  blindingRisk,
  coordinationIssues,
}: ExportPDFButtonProps) {
  const exportMutation = trpc.report.exportProtectionAnalysis.useMutation({
    onSuccess: (data) => {
      // Converter base64 para blob
      const binaryString = atob(data.pdfBase64);
      const bytes = new Uint8Array(binaryString.length);
      for (let i = 0; i < binaryString.length; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }
      const blob = new Blob([bytes], { type: "application/pdf" });

      // Criar link de download
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = data.filename;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);

      toast.success("Relatório exportado com sucesso!");
    },
    onError: (error) => {
      toast.error("Erro ao exportar relatório: " + error.message);
    },
  });

  const handleExport = () => {
    exportMutation.mutate({
      feederName,
      gdActive,
      gdName,
      gdCapacity,
      sourceImpedanceR,
      resultsWithoutGD,
      resultsWithGD,
      failures,
      blindingRisk,
      coordinationIssues,
    });
  };

  return (
    <Button
      onClick={handleExport}
      disabled={exportMutation.isPending}
      className="w-full flex items-center gap-2"
      variant="default"
    >
      {exportMutation.isPending ? (
        <>
          <Loader2 className="w-4 h-4 animate-spin" />
          Gerando PDF...
        </>
      ) : (
        <>
          <Download className="w-4 h-4" />
          Exportar Relatório em PDF
        </>
      )}
    </Button>
  );
}
