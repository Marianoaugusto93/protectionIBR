import React, { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { Badge } from "@/components/ui/badge";
import { AlertCircle, Zap, Shield } from "lucide-react";

interface AdvancedControlsProps {
  gdCapacity: number;
  onGDCapacityChange: (capacity: number) => void;
  sourceImpedanceR: number;
  onSourceImpedanceChange: (impedance: number) => void;
  devicePickupCurrents: Record<number, number>;
  onDevicePickupChange: (deviceId: number, pickup: number) => void;
  protectionDevices: Array<{ id: number; name: string; type: string; pickupCurrent: number }>;
}

export default function AdvancedControls({
  gdCapacity,
  onGDCapacityChange,
  sourceImpedanceR,
  onSourceImpedanceChange,
  devicePickupCurrents,
  onDevicePickupChange,
  protectionDevices,
}: AdvancedControlsProps) {
  const [expandedDevice, setExpandedDevice] = useState<number | null>(null);

  return (
    <div className="space-y-6">
      {/* GD Capacity Control */}
      <Card className="bg-white shadow-md">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <Zap className="w-5 h-5 text-yellow-500" />
            Capacidade da Geração Distribuída
          </CardTitle>
          <CardDescription>
            Ajuste a potência da usina GD (impacta a contribuição para curto-circuito)
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-sm font-medium">Potência: {gdCapacity} kW</label>
              <Badge variant="outline">{(gdCapacity / 1000).toFixed(1)} MW</Badge>
            </div>
            <Slider
              value={[gdCapacity]}
              onValueChange={(value) => onGDCapacityChange(value[0])}
              min={100}
              max={5000}
              step={100}
              className="w-full"
            />
            <div className="flex justify-between text-xs text-muted-foreground">
              <span>100 kW</span>
              <span>5 MW</span>
            </div>
          </div>
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 text-sm">
            <p className="text-blue-900">
              <strong>Impacto:</strong> Maior capacidade = maior contribuição para curto-circuito nas barras próximas
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Source Impedance Control */}
      <Card className="bg-white shadow-md">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <Shield className="w-5 h-5 text-blue-500" />
            Força da Fonte (Subestação)
          </CardTitle>
          <CardDescription>
            Ajuste a impedância da fonte para simular subestações fracas ou fortes
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-sm font-medium">Impedância R: {sourceImpedanceR.toFixed(4)} Ω</label>
              <Badge variant="outline">
                {sourceImpedanceR < 0.05 ? "Forte" : sourceImpedanceR < 0.15 ? "Normal" : "Fraca"}
              </Badge>
            </div>
            <Slider
              value={[sourceImpedanceR]}
              onValueChange={(value) => onSourceImpedanceChange(value[0])}
              min={0.01}
              max={0.5}
              step={0.01}
              className="w-full"
            />
            <div className="flex justify-between text-xs text-muted-foreground">
              <span>0.01 Ω (Forte)</span>
              <span>0.5 Ω (Fraca)</span>
            </div>
          </div>
          <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 text-sm">
            <p className="text-amber-900">
              <strong>Impacto:</strong> Fonte fraca reduz o curto-circuito total, podendo causar falha de proteção
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Device Pickup Controls */}
      <Card className="bg-white shadow-md">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <Shield className="w-5 h-5 text-green-500" />
            Sensibilidade dos Equipamentos de Proteção
          </CardTitle>
          <CardDescription>
            Ajuste o pickup current (corrente de atuação) de cada equipamento
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {protectionDevices.map((device) => (
            <div key={device.id} className="border border-border rounded-lg p-4 space-y-3">
              <button
                onClick={() => setExpandedDevice(expandedDevice === device.id ? null : device.id)}
                className="w-full flex items-center justify-between hover:bg-muted/50 p-2 rounded transition-colors"
              >
                <div className="flex items-center gap-2">
                  <span className="font-medium">{device.name}</span>
                  <Badge variant="outline" className="text-xs">
                    {device.type === "fuse" ? "Fusível" : "Religador"}
                  </Badge>
                </div>
                <span className="text-sm text-muted-foreground">
                  {devicePickupCurrents[device.id] || device.pickupCurrent} A
                </span>
              </button>

              {expandedDevice === device.id && (
                <div className="space-y-3 pt-3 border-t border-border">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <label className="text-sm font-medium">
                        Pickup Current: {(devicePickupCurrents[device.id] || device.pickupCurrent).toFixed(0)} A
                      </label>
                      <Badge variant="secondary" className="text-xs">
                        Original: {device.pickupCurrent.toFixed(0)} A
                      </Badge>
                    </div>
                    <Slider
                      value={[devicePickupCurrents[device.id] || device.pickupCurrent]}
                      onValueChange={(value) => onDevicePickupChange(device.id, value[0])}
                      min={50}
                      max={500}
                      step={10}
                      className="w-full"
                    />
                    <div className="flex justify-between text-xs text-muted-foreground">
                      <span>50 A (Sensível)</span>
                      <span>500 A (Insensível)</span>
                    </div>
                  </div>

                  <div className="bg-slate-50 border border-slate-200 rounded-lg p-3 text-sm space-y-1">
                    <p className="font-medium text-slate-900">Cenários de ajuste:</p>
                    <ul className="text-slate-700 space-y-1 text-xs">
                      <li>• <strong>Aumentar pickup:</strong> Reduz sensibilidade, pode não detectar faltas</li>
                      <li>• <strong>Diminuir pickup:</strong> Aumenta sensibilidade, pode causar atuação indevida</li>
                      <li>• <strong>Coordenação:</strong> Equipamentos a montante devem ter pickup maior</li>
                    </ul>
                  </div>
                </div>
              )}
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Warning Card */}
      <Card className="bg-red-50 border-red-200 shadow-md">
        <CardContent className="pt-6 flex gap-3">
          <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
          <div className="space-y-2">
            <p className="font-semibold text-red-900">Cenários Críticos a Explorar:</p>
            <ul className="text-red-800 space-y-1 text-sm">
              <li>• Fonte fraca + GD de alta capacidade = Blinding (proteção cega)</li>
              <li>• Pickup muito alto = Falha na detecção de faltas</li>
              <li>• Falta de coordenação = Atuação de múltiplos equipamentos</li>
              <li>• GD reduz ICC em barras distantes = Proteção não atua</li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
