# Guia de Instalação Offline - Protection_IBR

## 📋 Pré-requisitos

- **Node.js** v18+ ([Download](https://nodejs.org/))
- **pnpm** (instale com: `npm install -g pnpm`)
- **MySQL** 5.7+ ou **TiDB** ([Download MySQL](https://dev.mysql.com/downloads/mysql/))

## 🚀 Passos de Instalação

### 1. Extrair o Projeto

```bash
unzip Protection_IBR.zip
cd Protection_IBR
```

### 2. Instalar Dependências

```bash
pnpm install
```

### 3. Configurar Banco de Dados

#### Criar banco de dados no MySQL

```bash
mysql -u root -p
```

```sql
CREATE DATABASE protection_ibr CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
EXIT;
```

#### Criar arquivo `.env`

Na raiz do projeto, crie um arquivo `.env` com:

```env
# Banco de Dados
DATABASE_URL="mysql://root:sua_senha@localhost:3306/protection_ibr"

# Segurança
JWT_SECRET="chave-secreta-aleatoria-minimo-32-caracteres-aqui"

# OAuth (valores dummy para offline)
VITE_APP_ID="offline-app"
OAUTH_SERVER_URL="http://localhost:3000"
VITE_OAUTH_PORTAL_URL="http://localhost:3000"
OWNER_OPEN_ID="offline-user"
OWNER_NAME="Usuário Local"

# APIs (valores dummy para offline)
BUILT_IN_FORGE_API_URL="http://localhost:3000"
BUILT_IN_FORGE_API_KEY="offline-key"
VITE_FRONTEND_FORGE_API_KEY="offline-key"
VITE_FRONTEND_FORGE_API_URL="http://localhost:3000"

# Analytics (opcional)
VITE_ANALYTICS_ENDPOINT="http://localhost:3000"
VITE_ANALYTICS_WEBSITE_ID="offline"
VITE_APP_TITLE="Protection IBR - Simulador de GD"
VITE_APP_LOGO="/logo.svg"
```

**Substitua:**
- `root` pelo seu usuário MySQL
- `sua_senha` pela sua senha MySQL

### 4. Criar Tabelas do Banco de Dados

```bash
pnpm db:push
```

Este comando cria automaticamente todas as tabelas necessárias.

### 5. Popular Dados de Exemplo (Opcional)

```bash
npx tsx seed-db.mjs
```

Isso cria dados de exemplo para testar o simulador.

### 6. Iniciar o Servidor

```bash
pnpm dev
```

Você verá:

```
Server running on http://localhost:3000/
```

### 7. Acessar o Aplicativo

Abra seu navegador e acesse:

```
http://localhost:3000
```

## 🎮 Usando o Simulador

1. Clique em **"Iniciar Simulação"** na página inicial
2. Use o **toggle** para ligar/desligar a GD
3. Clique em **"Mostrar Controles Avançados"** para ajustar:
   - Capacidade da GD
   - Impedância da fonte
   - Sensibilidade dos equipamentos de proteção
4. Veja os resultados atualizados em tempo real
5. Clique em **"Exportar Relatório em PDF"** para gerar análise

## 🔧 Troubleshooting

### Erro: "Cannot find module"

```bash
pnpm install
pnpm db:push
```

### Erro: "Connection refused" (Banco de Dados)

Verifique se MySQL está rodando:

```bash
# Windows
net start MySQL80

# macOS
brew services start mysql

# Linux
sudo systemctl start mysql
```

### Porta 3000 já em uso

Modifique em `server/_core/index.ts`:

```typescript
const PORT = process.env.PORT || 3001;
```

Depois rode:

```bash
PORT=3001 pnpm dev
```

### Limpar cache e reinstalar

```bash
rm -rf node_modules pnpm-lock.yaml
pnpm install
pnpm db:push
pnpm dev
```

## 📁 Estrutura do Projeto

```
Protection_IBR/
├── client/                    # Frontend React
│   ├── src/
│   │   ├── pages/
│   │   │   ├── Home.tsx      # Página inicial
│   │   │   └── Simulator.tsx # Simulador interativo
│   │   ├── components/
│   │   │   ├── FeederDiagram.tsx
│   │   │   ├── ShortCircuitTable.tsx
│   │   │   ├── ComparisonChart.tsx
│   │   │   ├── AdvancedControls.tsx
│   │   │   ├── ProtectionFailureAnalysis.tsx
│   │   │   └── ExportPDFButton.tsx
│   │   └── lib/
│   │       └── trpc.ts       # Cliente tRPC
│   └── public/               # Arquivos estáticos
├── server/                    # Backend Express
│   ├── routers.ts            # Procedimentos tRPC
│   ├── routers/
│   │   └── report.ts         # Exportação PDF
│   ├── db.ts                 # Helpers de BD
│   ├── calculations.ts       # Cálculos de curto-circuito
│   ├── pdf-report.ts         # Geração de PDF
│   └── _core/                # Framework (não editar)
├── drizzle/
│   └── schema.ts             # Schema do banco de dados
├── package.json              # Dependências
├── .env                      # Variáveis de ambiente
└── seed-db.mjs               # Script de dados de exemplo
```

## 📝 Comandos Úteis

```bash
# Iniciar servidor de desenvolvimento
pnpm dev

# Executar testes
pnpm test

# Verificar erros TypeScript
pnpm check

# Formatar código
pnpm format

# Build para produção
pnpm build

# Iniciar servidor de produção
pnpm start

# Resetar banco de dados
pnpm db:push

# Gerar migrações
drizzle-kit generate
```

## ✅ Checklist Final

- [ ] Node.js v18+ instalado
- [ ] pnpm instalado
- [ ] MySQL rodando
- [ ] Arquivo `.env` criado
- [ ] `pnpm install` executado
- [ ] `pnpm db:push` executado
- [ ] `npx tsx seed-db.mjs` executado (opcional)
- [ ] `pnpm dev` rodando
- [ ] Acessar `http://localhost:3000` no navegador
- [ ] Simulador carregando corretamente

## 🆘 Suporte

Se encontrar problemas:

1. Verifique se todas as dependências estão instaladas: `pnpm install`
2. Limpe cache: `rm -rf node_modules && pnpm install`
3. Verifique conexão com MySQL: `mysql -u root -p`
4. Verifique arquivo `.env` com credenciais corretas
5. Consulte logs do servidor: `pnpm dev`

Bom uso! 🚀
