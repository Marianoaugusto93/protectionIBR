# Protection_IBR - TODO

## Arquitetura e Dados
- [x] Definir modelo de dados para alimentador radial (barras, linhas, equipamentos de proteção)
- [x] Definir algoritmo de cálculo de curto-circuito (com e sem GD)
- [x] Criar schema de banco de dados para configuração do sistema

## Backend (tRPC)
- [x] Implementar tabelas Drizzle para alimentador, equipamentos de proteção, cenários
- [x] Criar procedimento para calcular níveis de curto-circuito
- [x] Criar procedimento para listar/atualizar estado da GD
- [x] Implementar testes Vitest para cálculos (14 testes passando)

## Frontend - Visualização
- [x] Criar componente de diagrama do alimentador radial (SVG/Canvas)
- [x] Criar componente de exibição de níveis de curto-circuito (tabela/cards)
- [x] Criar componente de gráficos comparativos (com/sem GD)

## Frontend - Interatividade
- [x] Implementar toggle para ligar/desligar GD
- [x] Implementar controles de parâmetros do sistema (impedâncias, potências)
- [x] Implementar atualização dinâmica de visualizações ao alterar estado

## Integração
- [x] Conectar frontend com procedimentos tRPC
- [x] Testar fluxo completo de simulação
- [x] Validar cálculos e visualizações

## Entrega
- [x] Criar checkpoint final
- [x] Documentar uso do site


## Controles Avançados (Nova Fase)
- [x] Criar componente de sliders para ajustar capacidade da GD
- [x] Criar componente de sliders para ajustar impedância da fonte
- [x] Criar componente de sliders para ajustar pickup current dos equipamentos
- [x] Implementar cálculos dinâmicos com parâmetros ajustáveis
- [x] Criar análise de falhas de proteção (blinding, falta de detecção)
- [x] Implementar alertas visuais para cenários críticos
- [x] Criar relatório de análise de proteção


## Exportação de Relatório em PDF
- [x] Criar serviço de geração de PDF no backend
- [x] Criar componente de botão de exportação
- [x] Implementar formatação de relatório detalhado
- [x] Testar exportação e validar PDF gerado
